# JullBoy

Emulador Android de **Game Boy, Game Boy Color y Game Boy Advance** con biblioteca inteligente, Quick Save/Load, avance rápido configurable y protección de partidas.

JullBoy es una **versión modificada de [RavenEmu](https://github.com/GhostPunishR/RavenEmu)** de GhostPunishR (licencia **AGPL-3.0**), que usa los núcleos [RavenCore](https://github.com/GhostPunishR/RavenCore). Los créditos, la licencia y el código original se conservan; ver [JULLBOY.md](JULLBOY.md) para el detalle de lo que se cambió. Proyecto independiente, no afiliado a Nintendo. No incluye juegos ni BIOS.

> **Estado: alfa.** El código se ha escrito pero **no se ha compilado ni probado en un teléfono** por quien lo escribió. Lo primero que debes hacer es compilarlo con GitHub Actions (abajo) y revisar el resultado. Las funciones se describen tal como están implementadas; nada está marcado como «probado» si no lo está.

## Compilar el APK desde el teléfono (solo navegador)

1. Crea un **fork** de tu repositorio en GitHub (o un repositorio nuevo) y sube el contenido de este ZIP a la rama `main` (en la web: *Add file → Upload files*; en el móvil conviene la vista de escritorio del navegador).
2. Abre la pestaña **Actions**. Si GitHub pide habilitar los workflows, acéptalo.
3. Entra en el workflow **JullBoy Compilación** → **Run workflow** (o se lanza solo al hacer push a `main`).
4. Cuando termine (unos 10–20 min la primera vez), abre el run y baja a **Artifacts**: descarga **`jullboy-apk-prueba`**, descomprime el ZIP y obtendrás `androidApp-beta.apk`.
5. Instálalo en el teléfono (permite «instalar apps desconocidas» para tu navegador o gestor de archivos).

El APK de prueba está firmado con la clave de depuración, **sin secretos**. Si en el futuro añades los secretos `ANDROID_KEYSTORE_BASE64` y `ANDROID_KEYSTORE_PASSWORD`, el workflow también publica un APK firmado en *Releases*. Ver [RELEASING.md](RELEASING.md).

### Si falla la compilación
Abre el run fallido → el job en rojo → el paso en rojo → copia las últimas ~40 líneas del log (busca `error:` o `e: file:///…`) y pégalas a tu asistente. El APK de prueba se sube **justo después de compilar**, antes de los tests: si solo fallan tests o *lint*, el APK sigue disponible.

## Instalación junto a RavenEmu
JullBoy usa el identificador `com.jullboy.app` (RavenEmu usaba `com.ravenemu.preview`). Por eso **se instala al lado de RavenEmu, no lo sustituye, y no comparte datos con él**: biblioteca, partidas y ajustes empiezan vacíos. Para llevar tus partidas, en RavenEmu usa «Exportar todas las sauvegardes (.zip)» y en JullBoy importa por juego.

## Qué añade JullBoy

- **Biblioteca inteligente** — importa una carpeta entera (con subcarpetas); JullBoy recuerda la carpeta (solo lectura, selector de Android) y la puede **reescanear** leyendo solo lo nuevo o modificado. Agrupa automáticamente por **saga** (Pokémon, Mario, Zelda, Metroid, Kirby…) con subseries (principal, Pinball, Mystery Dungeon…) y **nivel de confianza**: fiable → se asigna; probable → se asigna y es revisable; dudoso → «Sin clasificar». Distingue hacks y traducciones. Todo local, sin red.
- **Colecciones virtuales** — Favoritos, Jugados recientemente, Nunca jugados, Sin terminar, Hacks y traducciones, Sin clasificar, sagas y colecciones propias. Un juego puede estar en varias a la vez. **Nunca se mueven, renombran ni duplican ROM.**
- **Correcciones manuales** (hoja *Organizar*): editar título, cambiar saga, ignorar la detección, restablecer, marcar hack/terminado, favoritos, colecciones. Se guardan por juego y los escaneos futuros no las pisan. Búsqueda por título, saga y consola; orden A-Z / última partida / añadidos; vista cuadrícula y lista.
- **Inicio**: «Continuar jugando» y «Favoritos» arriba de la biblioteca.
- **Quick Save / Quick Load** — botones en la barra del lector y en el menú del juego, sobre uno de los 4 emplacements existentes (se elige en *Ajustes → Partida rápida*). Siempre del juego en curso; no tocan el `.sav`.
- **Avance rápido** — ×2, ×3, ×4 o «máxima» (8 imágenes por periodo), modo alternar o **mantener pulsado**, indicador en pantalla, velocidad global o **por juego**. La velocidad real depende del teléfono: no se promete una cifra.
- **Perfiles por juego** — velocidad de avance, filtro (Game Boy), escala entera; botón para volver a los valores globales.
- **Protección de partidas** — autoguardado de estado **aparte** (no usa tus emplacements) al salir o pasar a segundo plano, con oferta de **recuperar la sesión** tras un cierre inesperado; **3 copias rotativas** del `.sav` antes de abrir cada juego, restaurables desde *Organizar → Copias de la partida* (la partida actual pasa a ser otra copia: no se pierde nada).
- Límite de biblioteca ampliado a 1000 juegos.
- Identidad nueva: nombre, icono, paleta verde sobre fondo oscuro.

Se conservan: GB/GBC/GBA, importación de ROM y carpetas, carátulas, estados, controles táctiles y mandos, ajustes de imagen/sonido, transferencia y copia de partidas, cable link virtual y sin hilos, rewind, trucos, skins Delta y RetroAchievements.

## Límites conocidos (sin ocultarlos)
- **No compilado ni probado en dispositivo** por el autor del cambio. Los tests nuevos (clasificador de sagas y colecciones: 20 comprobaciones) se ejecutaron en aislamiento; el resto de tests y la compilación Android los ejecuta tu CI.
- La interfaz **existente** sigue en francés (heredada de RavenEmu); lo nuevo está en español. Traducir todo es un trabajo pendiente.
- El catálogo de sagas es pequeño (~43 sagas) y se amplía editando `shared/src/commonMain/kotlin/com/ravenemu/shared/library/SagaCatalog.kt`.
- «Sin terminar» se basa en lo que tú marques como terminado: el emulador no puede saberlo con fiabilidad.
- Las carátulas siguen como en RavenEmu (manuales, o en línea si lo activas); no hay carátulas generadas de reserva.
- Splash: se usa el del sistema con el nuevo icono; no hay pantalla de presentación propia.
- Fast Forward en «máxima» y el rewind consumen CPU/RAM: ajustables en *Ajustes*.
- iOS no se compila en CI salvo que definas la variable de repositorio `JULLBOY_BUILD_IOS=true`.

## Licencia y datos
[AGPL-3.0](LICENSE). Si distribuyes JullBoy (APK), debes ofrecer el código fuente de tu versión modificada: tu repositorio público cumple eso. Sin publicidad ni telemetría. Los nombres de tus archivos y partidas no salen del teléfono; las carátulas en línea son opcionales y están desactivadas por defecto ([PRIVACY.md](PRIVACY.md)).

**Antes de borrar nada, exporta tus partidas**: *Exportar todas las sauvegardes (.zip)* desde el menú ⋮ de la biblioteca.
