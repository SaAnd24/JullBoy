# JullBoy — registro de modificaciones sobre RavenEmu

Base: RavenEmu (GhostPunishR), AGPL-3.0, commit `de1c9cc` de `main`. Núcleos: RavenCore (pin sin cambios).

## Identidad
- `applicationId`: `com.ravenemu.preview` → `com.jullboy.app`. **El `namespace` y los paquetes `com.ravenemu.*` no cambian** (los símbolos JNI y `AndroidPolicyTest` dependen de ellos).
- Etiqueta de la app, `rootProject.name`, icono (`ic_launcher_raven.png`, pixel art), fondo del icono, paleta (`RavenColors.kt` y constantes equivalentes), carpeta de capturas `Pictures/JullBoy`, preferencias `jullboy_preferences`.
- Se conservan los créditos de RavenEmu/RavenCore en *Ajustes → À propos* y la licencia.

## Código nuevo
| Archivo | Función |
| --- | --- |
| `shared/.../library/SagaCatalog.kt` | Normalizador de títulos + catálogo local de sagas con confianza |
| `shared/.../library/LibraryOrganization.kt` | Modelo de metadatos, colecciones inteligentes, orden, contrato con el anfitrión |
| `shared/.../library/LibraryHome.kt` | Inicio, chips, hoja *Organizar*, diálogos |
| `androidApp/.../library/LibraryOrganizationStore.kt` | `organization.json` atómico (favoritos, correcciones, colecciones, perfiles, carpetas, firmas de escaneo) |
| `androidApp/.../library/SessionMarker.kt` | Marca de sesión para la recuperación |
| tests | `SagaCatalogTest`, `SmartCollectionsTest`, `LibraryOrganizationStoreTest`, `GbBatteryBackupTest` |

## Código modificado (principales)
- `GbLibraryUi`, `GbFolderImporter`, `GbRomLibrary`: reescaneo incremental con permiso persistente, `addedAt`, `remove()` (solo borra la copia privada de la ROM), límites 256→1000 juegos.
- `AndroidGbSession`, `GbSaveStateStore`, `GbBatteryStore`, `GbStateSlotsUi`: estado de recuperación `<hash>.auto.state`, copias rotativas `backups/<hash>.N.sav`, `quickLoad`.
- `Settings`, `SettingsScreen`, `AndroidSettingsStore`: velocidad/modo de avance rápido, emplacement rápido, autoguardado, perfiles.
- `GbVideoScreen`, `GbFastForward`, `GbPlayback`, `GbPlayerUi`, `RavenEmuApp`, `MainActivity`: botones Quick Save/Load, avance rápido mantenido, integración.
- `.github/workflows/multiplateforme.yml`: APK de prueba siempre publicado, firma opcional, iOS opt-in.

## Garantías de datos
- Los datos de organización y los de partidas son archivos distintos; borrar `organization.json` solo devuelve la clasificación automática.
- El estado de recuperación no usa los 4 emplacements; el `.sav` solo se escribe como antes (más copias de seguridad).
- Restaurar una copia del `.sav` guarda antes la actual como copia.
- Quick Load solo lee estados del juego activo (la clave es el SHA-256 de su ROM).
