# Politique de confidentialité de RavenEmu

Date d’entrée en vigueur : 22 octobre 2026

## Champ d’application

Cette politique décrit le fonctionnement de l’application Android RavenEmu, du site officiel et des ressources GitHub du projet.

## Application Android

RavenEmu fonctionne sans compte, sans télémétrie et sans publicité. Il propose une connexion facultative au service tiers RetroAchievements. Sans connexion, aucun échange avec ce service n’est effectué. L’application ne téléverse jamais les ROM, sauvegardes, états instantanés ni pochettes.

Les données suivantes peuvent être créées ou analysées localement sur l’appareil :

- chemins de dossiers autorisés par l’utilisateur ;
- métadonnées et empreintes de jeux ;
- sauvegardes et états instantanés ;
- pochettes choisies ou générées localement ;
- préférences d’affichage, d’audio et de commandes ;
- mesures de performance affichées dans l’APK Debug.

Ces données restent sous le contrôle de l’utilisateur et peuvent être supprimées en retirant les fichiers concernés, en effaçant les données de l’application ou en désinstallant RavenEmu.

## RetroAchievements (facultatif)

Lors de la connexion choisie par l’utilisateur, le nom de compte et le mot de passe sont envoyés à `https://retroachievements.org` via HTTPS. Le mot de passe n’est pas conservé. Le jeton retourné est chiffré avec Android Keystore dans un fichier exclu des sauvegardes Android. La déconnexion efface ce fichier ; depuis le menu en jeu, elle ferme le client de la partie en cours dès la fermeture du dialogue du compte. Les succès déjà transmis ne sont pas supprimés.

Pendant une partie connectée, le SDK officiel transmet l’empreinte du jeu, les identifiants de jeu et de succès, les informations de session et de présence prévues par le jeu, ainsi que le nom/jeton du compte. Le service reçoit aussi les informations techniques d’une connexion HTTPS, dont l’adresse IP et l’identifiant du client (User-Agent) : versions de RavenEmu, d’Android, du moteur RavenCore et du SDK, et architecture du processeur. Les échanges servent à reconnaître la ROM, télécharger les conditions des succès et enregistrer leur obtention. La mémoire et les fichiers du jeu ne sont pas téléversés. La consultation volontaire d’un classement demande ses scores au même service, avec les informations de session du compte. Les noms publics, scores et rangs retournés sont affichés dans l’application ; aucune demande de classement périodique n’est ajoutée. Le texte de présence déjà prévu par le SDK est aussi affiché localement.

Les badges des succès, l’image du jeu et le portrait du compte sont des images publiques, téléchargées en HTTPS depuis `https://media.retroachievements.org`. Pour RetroAchievements, c’est le seul autre hôte contacté, et l’application refuse toute image venant d’ailleurs ; aucune donnée n’y est envoyée au-delà de ce que comporte une requête HTTPS, avec le même identifiant du client, et les images sont conservées dans le cache de l’application, que le système peut vider et qu’effacer les données supprime.

Les informations enregistrées par RetroAchievements relèvent de sa [politique de confidentialité](https://retroachievements.org/privacy.php). RavenEmu ne stocke pas ces informations sur un serveur du projet. Les requêtes Softcore légitimes émises par le SDK sont désormais conservées localement dans un journal chiffré via Android Keystore et exclu des sauvegardes Android. Ce journal contient les paramètres de la requête d'origine, y compris le jeton du compte ; il est limité à 256 demandes et les nouvelles tentatives ne sont effectuées qu'après authentification du même compte, avec le jeton de cette connexion. Les échecs sont retentés pendant la session avec un délai progressif de 5 à 120 secondes. Les entrées sont retirées après confirmation de réussite et toute la file est effacée lors d'une déconnexion explicite ou de la suppression des données de l'application. RavenEmu n'héberge pas ces données sur un serveur.

## Première session iOS

Le lecteur iOS importe uniquement les fichiers choisis dans Fichiers et en garde une copie dans l'espace privé de l'application, avec un index local, les sauvegardes et les états. Les préférences utilisent UserDefaults. Le lecteur ne téléverse pas ces fichiers ; les sauvegardes système de l'appareil dépendent des réglages iOS de l'utilisateur. Les exports `.sav` sont écrits à la destination choisie dans Fichiers, qui peut être un fournisseur distant choisi par l'utilisateur. La suppression de l'application peut supprimer son stockage privé.

RetroAchievements et le téléchargement des jaquettes ne sont pas raccordés dans cette première session iOS. Les mécanismes de jeton et de journal décrits plus haut concernent Android.

## Jaquettes en ligne (facultatif, version multiplateforme)

La nouvelle version multiplateforme de RavenEmu peut chercher les jaquettes manquantes de la bibliothèque sur `https://thumbnails.libretro.com`, un service tiers. Cette recherche est **désactivée par défaut** et ne démarre que si l’utilisateur l’active dans Réglages → Général → Bibliothèque.

Une fois activée, l’application télécharge l’index public des jaquettes de chaque console présente dans la bibliothèque (Game Boy, Game Boy Color, Game Boy Advance), puis l’image correspondant au nom de fichier de chaque jeu sans jaquette. Ce service reçoit donc les informations d’une connexion HTTPS, dont l’adresse IP de l’appareil, et, à travers les images demandées, le nom des jeux de la bibliothèque. Aucune ROM, empreinte, sauvegarde ni aucun état n’est envoyé. Les jaquettes sont conservées sur l’appareil. Les jeux absents de l’index ne sont pas recherchés de nouveau ; désactiver puis réactiver l’option relance la recherche.

Les images ainsi obtenues sont la propriété de leurs ayants droit ; RavenEmu ne les distribue pas et ne les inclut pas dans l’application.

## Câble link sans fil (Android)

Le câble link sans fil relie deux téléphones du même réseau local. Il est activé par défaut et se désactive dans Réglages → Général → Câble link. Il ne passe par aucun serveur : les échanges restent sur le réseau local, d’un téléphone à l’autre.

- **Annonce.** Seulement pendant que le jeu en cours se sert de son câble link, l’application s’annonce sur le réseau local (DNS-SD/mDNS) et cherche les autres téléphones. L’annonce indique le modèle du téléphone, la famille de console (Game Boy ou Game Boy Advance), la version du protocole et un identifiant tiré au hasard à chaque lancement de l’application. Elle n’indique ni le jeu, ni le compte, ni aucun fichier. Les appareils du même réseau peuvent la voir.
- **Liaison.** Une fois deux téléphones reliés, chacun envoie à l’autre le modèle du téléphone et le nom de son fichier de jeu, affichés dans le menu du jeu, puis les données du câble link émulé. Aucune ROM, sauvegarde ni aucun état n’est envoyé.
- **Fin.** Rien n’est conservé après la liaison. L’annonce s’arrête quand le jeu ne se sert plus du câble, quand l’application passe en arrière-plan ou quand le réglage est désactivé.

## Accès aux fichiers

RavenEmu utilise le sélecteur de documents Android afin que l’utilisateur choisisse explicitement les dossiers accessibles. Le projet ne demande pas un accès global au stockage lorsque le sélecteur Android suffit.

L’utilisateur reste responsable des ROM, BIOS et autres fichiers qu’il choisit d’ouvrir. RavenEmu ne fournit aucun contenu protégé.

## Site et services GitHub

Le site officiel est publié avec GitHub Pages. Le dépôt, les issues, les téléchargements et les avis de sécurité sont fournis par GitHub. Ces services peuvent traiter des données techniques conformément à leurs propres politiques.

RavenEmu n’ajoute aucun outil d’analyse publicitaire ou de suivi au site officiel.

## Conservation et partage

Le projet ne possède pas de base de données d’utilisateurs et ne vend aucune donnée personnelle. Les informations publiées volontairement dans une issue, une pull request ou une discussion deviennent visibles selon les règles de GitHub.

Ne publiez jamais de chemin personnel, ROM, BIOS, sauvegarde, clé, secret ou jeton dans un rapport public.

## Enfants

RavenEmu ne cherche pas à collecter de données relatives aux enfants et ne crée aucun compte propre au projet. La connexion facultative RetroAchievements utilise un compte tiers existant.

## Évolution de cette politique

Cette politique peut être mise à jour si les fonctions de l’application, le mode de distribution ou les services utilisés changent. La date d’entrée en vigueur sera alors actualisée.

## Contact

Pour une question générale, utilisez les issues sans publier de donnée sensible.

Pour un problème de confidentialité nécessitant un échange privé, utilisez [un avis de sécurité privé](https://github.com/GhostPunishR/RavenEmu/security/advisories/new) et précisez qu’il s’agit d’une demande de confidentialité.


