package com.ravenemu.shared.library

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class SmartCollectionsTest {
    private fun game(id: String, name: String, platform: GamePlatform = GamePlatform.GBA, added: Long = 0L) =
        GameEntry(id, name, platform, addedAt = added)

    private val ruby = game("ruby", "Pokemon - Ruby Version (USA).gba")
    private val emerald = game("emerald", "Pokemon - Emerald Version (USA).gba")
    private val pinball = game("pinball", "Pokemon Pinball (USA).gbc", GamePlatform.GBC)
    private val marioLand = game("land", "Super Mario Land (World).gb", GamePlatform.GB)
    private val unknown = game("misc", "Some Random Game.gba")
    private val all = listOf(ruby, emerald, pinball, marioLand, unknown)

    private fun collection(list: List<LibraryCollection>, id: String) = list.firstOrNull { it.id == id }

    @Test
    fun sagasGroupGamesAcrossConsolesWithoutDuplicatingThem() {
        val collections = SmartCollections.build(all, emptyMap(), emptyList())
        val pokemon = assertNotNull(collection(collections, SmartCollections.sagaId("Pokémon")))
        assertEquals(setOf("ruby", "emerald", "pinball"), pokemon.gameIds)
        // Una saga con un solo juego no crea colección por su cuenta.
        assertEquals(null, collection(collections, SmartCollections.sagaId("Mario")))
    }

    @Test
    fun unclassifiedHoldsGamesWithoutASaga() {
        val collections = SmartCollections.build(all, emptyMap(), emptyList())
        assertEquals(setOf("misc"), collection(collections, SmartCollections.UNCLASSIFIED)?.gameIds)
    }

    @Test
    fun aManualSagaWinsAndCreatesItsCollectionEvenWithOneGame() {
        val metas = mapOf("misc" to GameMeta(sagaOverride = "Mario"))
        val collections = SmartCollections.build(all, metas, emptyList())
        assertEquals(setOf("misc", "land"), collection(collections, SmartCollections.sagaId("Mario"))?.gameIds)
        assertFalse("misc" in collection(collections, SmartCollections.UNCLASSIFIED)?.gameIds.orEmpty())
    }

    @Test
    fun ignoringADetectionSendsTheGameBackToUnclassified() {
        val metas = mapOf("ruby" to GameMeta(sagaIgnored = true))
        val collections = SmartCollections.build(all, metas, emptyList())
        assertTrue("ruby" in collection(collections, SmartCollections.UNCLASSIFIED)!!.gameIds)
        assertEquals(setOf("emerald", "pinball"), collection(collections, SmartCollections.sagaId("Pokémon"))?.gameIds)
        val classification = SmartCollections.classify(ruby, metas["ruby"])
        assertEquals(ClassificationSource.IGNORED, classification.source)
    }

    @Test
    fun playedFavoriteAndUnfinishedCollectionsFollowTheMetadata() {
        val metas = mapOf(
            "ruby" to GameMeta(favorite = true, lastPlayedAt = 200L, playCount = 3),
            "emerald" to GameMeta(lastPlayedAt = 100L, playCount = 1, completed = true),
        )
        val collections = SmartCollections.build(all, metas, emptyList())
        assertEquals(setOf("ruby"), collection(collections, SmartCollections.FAVORITES)?.gameIds)
        assertEquals(setOf("ruby", "emerald"), collection(collections, SmartCollections.RECENT)?.gameIds)
        assertEquals(setOf("ruby"), collection(collections, SmartCollections.UNFINISHED)?.gameIds)
        assertEquals(setOf("pinball", "land", "misc"), collection(collections, SmartCollections.UNPLAYED)?.gameIds)
        assertEquals(listOf("ruby"), SmartCollections.continuePlaying(all, metas).map { it.id })
        assertEquals(listOf("ruby", "emerald"), SmartCollections.recentlyPlayed(all, metas).map { it.id })
    }

    @Test
    fun hacksAreCollectedFromNamesAndManualMarks() {
        val hack = game("hack", "Pokemon Radical Red.gba")
        val metas = mapOf("land" to GameMeta(hackOverride = true), "ruby" to GameMeta(hackOverride = false))
        val collections = SmartCollections.build(all + hack, metas, emptyList())
        assertEquals(setOf("hack", "land"), collection(collections, SmartCollections.HACKS)?.gameIds)
    }

    @Test
    fun customCollectionsOverlapWithoutDuplicatingGames() {
        val custom = listOf(CustomCollection("c1", "Para el viaje"), CustomCollection("c2", "Vacía"))
        val metas = mapOf(
            "ruby" to GameMeta(collections = setOf("c1")),
            "land" to GameMeta(collections = setOf("c1", "gone")),
        )
        val collections = SmartCollections.build(all, metas, custom)
        assertEquals(setOf("ruby", "land"), collection(collections, SmartCollections.customId("c1"))?.gameIds)
        // Una colección personalizada vacía sigue existiendo para poder llenarla.
        assertEquals(emptySet(), collection(collections, SmartCollections.customId("c2"))?.gameIds)
        // Y el juego sigue en su saga.
        assertTrue("ruby" in collection(collections, SmartCollections.sagaId("Pokémon"))!!.gameIds)
    }

    @Test
    fun displayTitleUsesTheManualTitleThenTheCleanedName() {
        assertEquals("Pokemon - Ruby Version", SmartCollections.displayTitle(ruby, null))
        assertEquals("Mi Rubí", SmartCollections.displayTitle(ruby, GameMeta(titleOverride = "Mi Rubí")))
        assertEquals("Pokemon - Ruby Version", SmartCollections.displayTitle(ruby, GameMeta(titleOverride = "  ")))
    }

    @Test
    fun sortingByTitleLastPlayedAndAdded() {
        val a = game("a", "Alpha.gb", GamePlatform.GB, added = 5)
        val b = game("b", "Beta.gb", GamePlatform.GB, added = 9)
        val c = game("c", "Gamma.gb", GamePlatform.GB, added = 1)
        val withTitles = listOf(a, b, c).map { it.copy(displayTitle = it.title.removeSuffix(".gb")) }
        val metas = mapOf("c" to GameMeta(lastPlayedAt = 50L), "a" to GameMeta(lastPlayedAt = 10L))
        assertEquals(listOf("a", "b", "c"), SmartCollections.sorted(withTitles, metas, LibrarySort.TITLE).map { it.id })
        assertEquals(listOf("c", "a", "b"), SmartCollections.sorted(withTitles, metas, LibrarySort.LAST_PLAYED).map { it.id })
        assertEquals(listOf("b", "a", "c"), SmartCollections.sorted(withTitles, metas, LibrarySort.ADDED).map { it.id })
    }

    @Test
    fun searchFindsTheDisplayedTitleTheFileNameAndTheSaga() {
        val entry = ruby.copy(displayTitle = "Mi Rubí")
        assertEquals(1, LibraryCatalog.search(listOf(entry), "rub", null).size)
        assertEquals(1, LibraryCatalog.search(listOf(entry), "Ruby Version", null).size)
        val text = SmartCollections.searchText(entry, SmartCollections.classify(entry, null))
        assertTrue("Pokémon" in text)
    }
}
