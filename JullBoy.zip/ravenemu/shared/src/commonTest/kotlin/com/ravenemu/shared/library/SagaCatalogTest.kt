package com.ravenemu.shared.library

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class SagaCatalogTest {
    private fun match(name: String) = SagaCatalog.classify(name)

    @Test
    fun titleNormalizationRemovesExtensionRegionsAndTags() {
        assertEquals("Pokemon - Emerald Version", TitleNormalizer.displayTitle("Pokemon - Emerald Version (USA, Europe).gba"))
        assertEquals("Tetris", TitleNormalizer.displayTitle("Tetris (World) (Rev 1) [!].gb"))
        assertEquals("Super Mario Land", TitleNormalizer.displayTitle("Super_Mario_Land.gb"))
        assertEquals("Super Mario Land", TitleNormalizer.displayTitle("Super.Mario.Land.gb"))
        assertEquals(
            "The Legend of Zelda - Link's Awakening DX",
            TitleNormalizer.displayTitle("Legend of Zelda, The - Link's Awakening DX (USA, Europe).gbc"),
        )
        // Sin extensión (iOS): no se rompe nada.
        assertEquals("Tetris", TitleNormalizer.displayTitle("Tetris"))
        // Un nombre que solo son etiquetas no deja un título vacío.
        assertTrue(TitleNormalizer.displayTitle("(USA).gb").isNotBlank())
    }

    @Test
    fun keysIgnoreAccentsCaseAndPunctuation() {
        assertEquals("pokemon ruby sapphire", TitleNormalizer.key("Pokémon – Ruby & Sapphire"))
        assertEquals("links awakening", TitleNormalizer.key("Link's Awakening"))
        assertEquals("", TitleNormalizer.key("!!!"))
    }

    @Test
    fun mainlinePokemonIsReliableAndKeepsItsSubseries() {
        val emerald = match("Pokemon - Emerald Version (USA, Europe).gba")
        assertEquals("Pokémon", emerald.saga)
        assertEquals("Serie principal", emerald.subseries)
        assertEquals(SagaConfidence.RELIABLE, emerald.confidence)
        assertFalse(emerald.modified)
        assertEquals("Serie principal", match("Pokemon Esmeralda (Spain).gba").subseries)
        assertEquals(SagaConfidence.RELIABLE, match("Pokemon Esmeralda (Spain).gba").confidence)
    }

    @Test
    fun pokemonSpinOffsAreSeparatedFromTheMainSeries() {
        assertEquals("Pinball", match("Pokemon Pinball (USA).gbc").subseries)
        assertEquals("Pinball", match("Pokemon Pinball - Ruby & Sapphire (USA).gba").subseries)
        assertEquals("Mystery Dungeon", match("Pokemon Mystery Dungeon - Red Rescue Team.gba").subseries)
        assertEquals("Cartas (TCG)", match("Pokemon Trading Card Game (USA).gbc").subseries)
        assertEquals("Pokémon", match("Pokemon Mystery Dungeon - Red Rescue Team.gba").saga)
    }

    @Test
    fun hacksAndTranslationsAreNeverReliable() {
        val radicalRed = match("Pokemon Radical Red v4.1.gba")
        assertEquals("Pokémon", radicalRed.saga)
        assertTrue(radicalRed.modified)
        assertEquals(SagaConfidence.PROBABLE, radicalRed.confidence)
        val translated = match("Pokemon - FireRed Version [T+Spa].gba")
        assertTrue(translated.modified)
        assertEquals(SagaConfidence.PROBABLE, translated.confidence)
        assertTrue(match("Pokemon Emerald Kaizo.gba").modified)
    }

    @Test
    fun anUnknownTitleWithTheWordPokemonIsNotAnOfficialMainlineGame() {
        val unknown = match("Pokemon Fan Game Thing.gba")
        assertEquals("Pokémon", unknown.saga)
        assertNull(unknown.subseries)
        assertEquals(SagaConfidence.PROBABLE, unknown.confidence)
    }

    @Test
    fun aWeakHintAfterOtherWordsStaysDoubtful() {
        val doubtful = match("My Super Cool Hack - Mario Edition.gba")
        assertEquals(SagaConfidence.DOUBTFUL, doubtful.confidence)
        val unknown = match("Some Random Game (USA).gba")
        assertNull(unknown.saga)
        assertEquals(SagaConfidence.DOUBTFUL, unknown.confidence)
    }

    @Test
    fun marioWarioAndDonkeyKongAreDistinguished() {
        assertEquals("Mario", match("Super Mario Land (World).gb").saga)
        assertEquals("Mario", match("Mario vs. Donkey Kong (USA).gba").saga)
        assertEquals("Wario", match("Wario Land 4 (USA).gba").saga)
        assertEquals("Donkey Kong", match("Donkey Kong Country (USA).gba").saga)
        assertEquals("Mario Kart", match("Mario Kart - Super Circuit (USA).gba").subseries)
        assertEquals("Dr. Mario", match("Dr. Mario (World).gb").subseries)
    }

    @Test
    fun zeldaSubseriesAreRecognizedWhateverTheArticlePlacement() {
        val minish = match("Legend of Zelda, The - The Minish Cap (USA).gba")
        assertEquals("The Legend of Zelda", minish.saga)
        assertEquals("The Minish Cap", minish.subseries)
        assertEquals(SagaConfidence.RELIABLE, minish.confidence)
        assertEquals("Oracle", match("Legend of Zelda, The - Oracle of Ages (USA).gbc").subseries)
        assertEquals("Four Swords", match("Legend of Zelda, The - A Link to the Past & Four Swords (USA).gba").subseries)
    }

    @Test
    fun theCatalogOffersSagaNamesForManualCorrection() {
        assertTrue("Pokémon" in SagaCatalog.sagaNames)
        assertTrue("Mario" in SagaCatalog.sagaNames)
        assertTrue("Pinball" in SagaCatalog.subseriesOf("Pokémon"))
        assertEquals(SagaCatalog.sagaNames.sortedBy { it.lowercase() }, SagaCatalog.sagaNames)
    }
}
