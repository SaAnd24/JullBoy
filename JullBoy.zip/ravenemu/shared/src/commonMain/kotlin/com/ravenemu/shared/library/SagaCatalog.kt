package com.ravenemu.shared.library

/**
 * JullBoy · clasificación local de juegos por saga.
 *
 * Todo ocurre sin red, sin IA y de forma reproducible: se normaliza el nombre del
 * archivo, se compara con un catálogo de títulos y alias conocidos y se devuelve la
 * saga, la subserie y un nivel de confianza. Nada de esto toca los archivos ROM.
 *
 * Código común (Android e iOS): no usa API de la JVM.
 */

/** Qué tan segura está la clasificación automática. */
enum class SagaConfidence {
    /** El título coincide por completo con uno del catálogo: se clasifica solo. */
    RELIABLE,

    /** La saga es muy probable, pero el título trae texto extra (hack, subtítulo…): revisable. */
    PROBABLE,

    /** Solo hay una pista débil: el juego queda en «Sin clasificar» hasta que el usuario decida. */
    DOUBTFUL,
}

/** Resultado de [SagaCatalog.classify]. [saga] es null cuando no hay ninguna pista. */
data class SagaMatch(
    val saga: String?,
    val subseries: String?,
    val confidence: SagaConfidence,
    /** El título limpio, sin extensión, regiones ni etiquetas. */
    val title: String,
    /** El nombre indica un hack, una traducción de aficionado, un parche o un randomizer. */
    val modified: Boolean,
)

/** Normalización de nombres de archivo. Funciones puras y probadas. */
object TitleNormalizer {
    private val EXTENSIONS = listOf(".gba", ".gbc", ".gb")

    /** Palabras de etiqueta que delatan un archivo modificado por aficionados. */
    private val MODIFIED_WORDS = setOf(
        "hack", "hacked", "romhack", "kaizo", "randomizer", "randomiser", "translation", "translated",
        "traduccion", "traducido", "traducao", "patch", "patched", "fan", "mod", "remix",
    )

    /** Palabras sueltas del título que ya implican un hack (más estrictas que las etiquetas). */
    private val MODIFIED_TITLE_WORDS = setOf(
        "hack", "hacked", "romhack", "kaizo", "randomizer", "randomiser", "translation", "translated",
    )

    /** Quita la extensión .gb/.gbc/.gba (y una ruta, si la hay). */
    fun withoutExtension(fileName: String): String {
        val name = fileName.substringAfterLast('/').trim()
        val lower = name.lowercase()
        for (extension in EXTENSIONS) {
            if (lower.endsWith(extension)) return name.dropLast(extension.length).trim()
        }
        return name
    }

    /** El texto de cada grupo entre paréntesis o corchetes: «(USA)», «[T+Spa]»… */
    fun tags(baseName: String): List<String> {
        val result = ArrayList<String>()
        var index = 0
        while (index < baseName.length) {
            val close = when (baseName[index]) {
                '(' -> ')'
                '[' -> ']'
                else -> null
            }
            if (close == null) {
                index++
                continue
            }
            val end = baseName.indexOf(close, index + 1)
            if (end < 0) break
            result.add(baseName.substring(index + 1, end))
            index = end + 1
        }
        return result
    }

    /** El nombre sin los grupos entre paréntesis o corchetes. */
    fun stripTags(baseName: String): String {
        val out = StringBuilder()
        var index = 0
        while (index < baseName.length) {
            val c = baseName[index]
            val close = when (c) {
                '(' -> ')'
                '[' -> ']'
                else -> null
            }
            if (close == null) {
                out.append(c)
                index++
                continue
            }
            val end = baseName.indexOf(close, index + 1)
            if (end < 0) {
                out.append(baseName.substring(index))
                break
            }
            out.append(' ')
            index = end + 1
        }
        return out.toString()
    }

    /** El título que se muestra: sin extensión ni etiquetas, con espacios limpios. */
    fun displayTitle(fileName: String): String {
        val base = withoutExtension(fileName)
        var title = stripTags(base).replace('_', ' ')
        // «Super.Mario.Land»: los puntos hacen de espacios solo si no hay ninguno.
        if (!title.contains(' ') && title.count { it == '.' } >= 2) title = title.replace('.', ' ')
        title = collapseSpaces(title)
        title = moveArticle(title)
        title = title.trim { it == '-' || it == ' ' || it == ':' }
        return title.ifBlank { base.ifBlank { fileName.trim() } }
    }

    /** «Legend of Zelda, The - Link's Awakening» → «The Legend of Zelda - Link's Awakening». */
    private fun moveArticle(title: String): String {
        for (article in listOf("The", "A", "An")) {
            val marker = ", $article"
            val at = title.indexOf(marker)
            if (at <= 0) continue
            val after = title.substring(at + marker.length)
            val boundary = after.isEmpty() || after.startsWith(" - ") || after.startsWith(":") ||
                after.startsWith(" :")
            if (boundary) return "$article ${title.substring(0, at)}$after"
        }
        return title
    }

    private fun collapseSpaces(text: String): String {
        val out = StringBuilder()
        var pending = false
        for (c in text) {
            if (c == ' ' || c == '\t' || c == ' ') {
                pending = true
            } else {
                if (pending && out.isNotEmpty()) out.append(' ')
                pending = false
                out.append(c)
            }
        }
        return out.toString()
    }

    /**
     * Clave de comparación: minúsculas, sin acentos, sin apóstrofos y con cualquier otro
     * símbolo convertido en un único espacio. «Pokémon - Emerald» → «pokemon emerald».
     */
    fun key(text: String): String {
        val out = StringBuilder()
        var pending = false
        for (raw in text.lowercase()) {
            val c = fold(raw)
            when {
                c == '\'' || c == '’' || c == '`' || c == '´' -> Unit
                c in 'a'..'z' || c in '0'..'9' -> {
                    if (pending && out.isNotEmpty()) out.append(' ')
                    pending = false
                    out.append(c)
                }
                else -> pending = true
            }
        }
        return out.toString()
    }

    fun tokens(text: String): List<String> {
        val k = key(text)
        return if (k.isEmpty()) emptyList() else k.split(' ')
    }

    /** ¿El nombre indica un hack, una traducción o un parche? */
    fun looksModified(fileName: String): Boolean {
        val base = withoutExtension(fileName)
        for (tag in tags(base)) {
            if (tag.trim().let { it.length >= 2 && (it[0] == 'T' || it[0] == 't') && (it[1] == '+' || it[1] == '-') }) {
                return true
            }
            if (tokens(tag).any { it in MODIFIED_WORDS }) return true
        }
        return tokens(stripTags(base)).any { it in MODIFIED_TITLE_WORDS }
    }

    private fun fold(c: Char): Char = when (c) {
        'à', 'á', 'â', 'ã', 'ä', 'å' -> 'a'
        'ç' -> 'c'
        'è', 'é', 'ê', 'ë' -> 'e'
        'ì', 'í', 'î', 'ï' -> 'i'
        'ñ' -> 'n'
        'ò', 'ó', 'ô', 'õ', 'ö' -> 'o'
        'ù', 'ú', 'û', 'ü' -> 'u'
        'ý', 'ÿ' -> 'y'
        else -> c
    }
}

/** Catálogo local de sagas, mantenible a mano: basta añadir alias en [CATALOG]. */
object SagaCatalog {
    private class Rule(val phrase: List<String>, val subseries: String?, val modified: Boolean)

    private class Saga(val name: String, val rules: List<Rule>, val keywords: List<List<String>>)

    private class SagaBuilder(val name: String) {
        val rules = ArrayList<Rule>()
        val keywords = ArrayList<List<String>>()

        /** Pistas débiles: la saga es probable si aparecen al principio del título. */
        fun keywords(vararg phrases: String) {
            for (p in phrases) keywords.add(TitleNormalizer.tokens(p))
        }

        /** Títulos conocidos de una subserie. */
        fun sub(subseries: String?, vararg aliases: String) {
            for (a in aliases) rules.add(Rule(TitleNormalizer.tokens(a), subseries, false))
        }

        /** Hacks y mods conocidos: se asignan a la saga, pero siempre como «probable». */
        fun hack(vararg aliases: String) {
            for (a in aliases) rules.add(Rule(TitleNormalizer.tokens(a), SUB_HACKS, true))
        }
    }

    private const val SUB_HACKS = "Hacks y mods"

    private fun saga(name: String, build: SagaBuilder.() -> Unit): Saga {
        val builder = SagaBuilder(name)
        builder.build()
        return Saga(name, builder.rules, builder.keywords)
    }

    /** Palabras que no cuentan como «texto extra»: versión, región, idioma, números… */
    private val NOISE = setOf(
        "the", "a", "an", "and", "of", "version", "edition", "rev", "revision", "usa", "europe", "japan",
        "world", "spain", "france", "germany", "italy", "en", "es", "fr", "de", "it", "ja", "jp", "eu", "us",
        "english", "spanish", "french", "german", "italian", "japanese", "beta", "proto", "prototype", "demo",
        "sample", "unl", "sgb", "enhanced", "gb", "gbc", "gba",
        "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x",
    )

    /** Antes de una pista débil, estas palabras no impiden que cuente como «al principio». */
    private val LEADING = setOf("the", "a", "an", "super", "new")

    private val CATALOG: List<Saga> = listOf(
        saga("Pokémon") {
            keywords("pokemon", "pocket monsters")
            sub(
                "Serie principal",
                "pokemon red", "pokemon blue", "pokemon yellow", "pokemon green",
                "pokemon gold", "pokemon silver", "pokemon crystal",
                "pokemon ruby", "pokemon sapphire", "pokemon emerald",
                "pokemon fire red", "pokemon firered", "pokemon leaf green", "pokemon leafgreen",
                "pokemon rojo", "pokemon azul", "pokemon amarillo", "pokemon oro", "pokemon plata",
                "pokemon cristal", "pokemon rubi", "pokemon zafiro", "pokemon esmeralda",
                "pokemon rojo fuego", "pokemon verde hoja",
                "pokemon rouge", "pokemon bleu", "pokemon jaune", "pokemon or", "pokemon argent",
                "pokemon rubis", "pokemon saphir", "pokemon emeraude", "pokemon rouge feu",
                "pokemon vert feuille",
                "pokemon rosso", "pokemon blu", "pokemon giallo", "pokemon argento", "pokemon cristallo",
                "pokemon rubino", "pokemon zaffiro", "pokemon smeraldo", "pokemon rosso fuoco",
                "pokemon verde foglia",
            )
            sub("Pinball", "pokemon pinball", "pokemon pinball ruby sapphire")
            sub(
                "Mystery Dungeon",
                "pokemon mystery dungeon", "pokemon fushigi no dungeon",
                "pokemon mystery dungeon red rescue team",
            )
            sub("Cartas (TCG)", "pokemon trading card game", "pokemon card gb", "pokemon tcg")
            sub("Puzzle", "pokemon puzzle challenge", "pokemon puzzle league")
            hack(
                "pokemon radical red", "pokemon unbound", "pokemon light platinum", "pokemon dark rising",
                "pokemon glazed", "pokemon emerald kaizo", "pokemon emerald rogue", "pokemon clover",
                "pokemon ash gray", "pokemon rocket edition", "pokemon sacred gold", "pokemon storm silver",
                "pokemon liquid crystal", "pokemon prism", "pokemon crystal clear", "pokemon yellow legacy",
                "pokemon brown", "pokemon moemon", "pokemon blazed glazed", "pokemon fire red omega",
            )
        },
        saga("Mario") {
            keywords("mario")
            sub(
                "Plataformas",
                "super mario land", "super mario land 2 6 golden coins", "super mario bros deluxe",
                "super mario bros", "super mario advance", "super mario advance 2", "super mario advance 3",
                "super mario advance 4", "super mario advance 4 super mario bros 3",
                "super mario world super mario advance 2", "yoshis island super mario advance 3",
                "super mario world", "super mario bros 3", "super mario",
            )
            sub("Mario Kart", "mario kart super circuit", "mario kart")
            sub(
                "Deportes y fiesta",
                "mario golf", "mario golf gb", "mario golf advance tour", "mario tennis", "mario tennis gb",
                "mario tennis power tour", "mario party advance", "mario party",
            )
            sub("Dr. Mario", "dr mario", "dr mario puzzle league")
            sub("Mario & Luigi", "mario luigi", "mario and luigi", "mario luigi superstar saga", "mario and luigi superstar saga")
            sub("Mario vs. Donkey Kong", "mario vs donkey kong", "mario vs donkey kong march of the minis")
            sub("Otros", "mario pinball land", "mario picross", "mario no picross", "mario clash")
        },
        saga("Wario") {
            keywords("wario", "warioware")
            sub("Wario Land", "wario land", "wario land 3", "wario land 4", "wario land ii", "wario land super mario land 3")
            sub("WarioWare", "warioware", "wario ware", "warioware twisted", "warioware inc")
            sub("Otros", "wario blast")
        },
        saga("Donkey Kong") {
            keywords("donkey kong")
            sub("Donkey Kong Country", "donkey kong country", "donkey kong country 2", "donkey kong country 3")
            sub("Donkey Kong Land", "donkey kong land", "donkey kong land 2", "donkey kong land iii")
            sub("King of Swing", "donkey kong king of swing", "king of swing")
            sub("Clásico", "donkey kong", "donkey kong 94", "donkey kong gb")
        },
        saga("The Legend of Zelda") {
            keywords("zelda", "legend of zelda")
            sub(
                "Link's Awakening",
                "links awakening", "links awakening dx", "legend of zelda links awakening",
                "legend of zelda links awakening dx", "zelda links awakening",
            )
            sub(
                "Oracle",
                "oracle of seasons", "oracle of ages", "legend of zelda oracle of seasons",
                "legend of zelda oracle of ages", "zelda oracle of seasons", "zelda oracle of ages",
            )
            sub("The Minish Cap", "minish cap", "legend of zelda minish cap", "zelda minish cap")
            sub(
                "Four Swords",
                "four swords", "a link to the past four swords",
                "legend of zelda a link to the past four swords",
            )
            sub("A Link to the Past", "a link to the past", "link to the past")
        },
        saga("Metroid") {
            keywords("metroid")
            sub("Metroid II", "metroid 2 return of samus", "metroid ii return of samus", "return of samus")
            sub("Metroid Fusion", "metroid fusion")
            sub("Metroid Zero Mission", "metroid zero mission")
        },
        saga("Kirby") {
            keywords("kirby", "kirbys")
            sub("Dream Land", "kirbys dream land", "kirbys dream land 2", "kirbys dream land 3")
            sub("Nightmare in Dream Land", "kirby nightmare in dream land")
            sub("Amazing Mirror", "kirby and the amazing mirror", "kirby the amazing mirror")
            sub("Tilt 'n' Tumble", "kirby tilt n tumble", "kirby tilt and tumble")
            sub("Otros", "kirbys pinball land", "kirbys block ball", "kirbys star stacker", "kirbys dream course")
        },
        saga("Sonic") {
            keywords("sonic")
            sub("Sonic Advance", "sonic advance", "sonic advance 2", "sonic advance 3")
            sub("Otros", "sonic battle", "sonic pinball party", "sonic n", "sonic the hedgehog genesis")
        },
        saga("Final Fantasy") {
            keywords("final fantasy")
            sub(
                "Serie principal",
                "final fantasy iv advance", "final fantasy v advance", "final fantasy vi advance",
                "final fantasy i ii dawn of souls", "final fantasy dawn of souls",
            )
            sub("Tactics", "final fantasy tactics advance")
            sub("Legend / Adventure", "final fantasy legend", "final fantasy legend ii", "final fantasy legend iii", "final fantasy adventure")
        },
        saga("Dragon Quest") {
            keywords("dragon quest", "dragon warrior")
            sub("Monsters", "dragon quest monsters", "dragon warrior monsters", "dragon warrior monsters 2")
            sub("Serie principal", "dragon quest", "dragon warrior", "dragon quest characters torneko")
        },
        saga("Castlevania") {
            keywords("castlevania", "akumajou")
            sub("Circle of the Moon", "castlevania circle of the moon")
            sub("Harmony of Dissonance", "castlevania harmony of dissonance")
            sub("Aria of Sorrow", "castlevania aria of sorrow")
            sub("Clásicos GB", "castlevania the adventure", "castlevania adventure", "castlevania legends", "castlevania ii belmonts revenge", "castlevania belmonts revenge")
        },
        saga("Mega Man") {
            keywords("mega man", "megaman", "rockman")
            sub("Battle Network", "mega man battle network", "megaman battle network", "rockman exe")
            sub("Zero", "mega man zero", "megaman zero", "rockman zero")
            sub("Mega Man & Bass", "mega man and bass", "megaman and bass", "mega man bass")
            sub("Xtreme", "mega man xtreme", "megaman xtreme")
            sub("Clásicos GB", "mega man dr wilys revenge", "megaman dr wilys revenge", "mega man 2", "mega man 3", "mega man 4", "mega man 5")
        },
        saga("Fire Emblem") {
            keywords("fire emblem")
            sub(
                "Serie principal",
                "fire emblem", "fire emblem the sacred stones", "fire emblem sacred stones",
                "fire emblem the blazing blade", "fire emblem blazing blade", "fire emblem rekka no ken",
                "fire emblem seima no kouseki", "fire emblem fuuin no tsurugi",
            )
        },
        saga("Advance Wars") {
            keywords("advance wars", "game boy wars", "gameboy wars")
            sub("Serie principal", "advance wars", "advance wars 2 black hole rising", "game boy wars advance", "gameboy wars advance")
        },
        saga("Golden Sun") {
            keywords("golden sun")
            sub("Serie principal", "golden sun", "golden sun the lost age", "golden sun lost age")
        },
        saga("Harry Potter") {
            keywords("harry potter")
            sub("Piedra Filosofal", "harry potter and the sorcerers stone", "harry potter and the philosophers stone", "harry potter sorcerers stone")
            sub("Cámara Secreta", "harry potter and the chamber of secrets", "harry potter chamber of secrets")
            sub("Prisionero de Azkaban", "harry potter and the prisoner of azkaban", "harry potter prisoner of azkaban")
            sub("Quidditch", "harry potter quidditch world cup")
        },
        saga("Yoshi") {
            keywords("yoshi", "yoshis")
            sub("Yoshi's Island", "yoshis island")
            sub("Puzles", "yoshi", "yoshis cookie", "yoshis safari")
        },
        saga("Tetris") {
            keywords("tetris")
            sub("Serie principal", "tetris", "tetris dx", "tetris plus", "tetris worlds", "tetris adventure")
        },
        saga("Mother / EarthBound") {
            sub("Serie principal", "earthbound", "earthbound beginnings", "mother 1 2", "mother 3")
        },
        saga("Street Fighter") {
            keywords("street fighter")
            sub("Serie principal", "street fighter ii", "super street fighter ii turbo revival", "street fighter alpha 3")
        },
        saga("Mortal Kombat") {
            keywords("mortal kombat")
            sub("Serie principal", "mortal kombat", "mortal kombat ii", "mortal kombat 3", "mortal kombat 4", "mortal kombat advance", "mortal kombat deadly alliance")
        },
        saga("Crash Bandicoot") {
            keywords("crash bandicoot", "crash nitro kart", "crash fusion")
            sub("Serie principal", "crash bandicoot xs", "crash bandicoot the huge adventure", "crash bandicoot 2 n tranced")
        },
        saga("Spyro") {
            keywords("spyro")
            sub("Serie principal", "spyro season of ice", "spyro ripto's rage", "spyro attack of the rhynocs", "spyro orange the cortex conspiracy")
        },
        saga("Rayman") { keywords("rayman") },
        saga("Shantae") { keywords("shantae") },
        saga("Bomberman") { keywords("bomberman") },
        saga("Contra") {
            keywords("contra")
            sub("Serie principal", "contra advance the alien wars ex", "contra the alien wars", "operation c")
        },
        saga("Tony Hawk's") {
            keywords("tony hawks")
            sub("Serie principal", "tony hawks pro skater 2", "tony hawks pro skater 3", "tony hawks pro skater 4", "tony hawks underground")
        },
        saga("Need for Speed") { keywords("need for speed") },
        saga("Digimon") { keywords("digimon") },
        saga("Dragon Ball") { keywords("dragon ball", "dragonball") },
        saga("Yu-Gi-Oh!") { keywords("yu gi oh", "yugioh") },
        saga("Pac-Man") { keywords("pac man", "pacman") },
        saga("Medabots") { keywords("medabots", "medarot") },
        saga("Metal Gear") { keywords("metal gear") },
        saga("Boktai") { keywords("boktai") },
        saga("F-Zero") { keywords("f zero") },
        saga("Harvest Moon") { keywords("harvest moon") },
        saga("Naruto") { keywords("naruto") },
        saga("Mana") {
            sub("Serie principal", "sword of mana", "final fantasy adventure", "seiken densetsu", "legend of mana")
        },
        saga("Game & Watch") { keywords("game and watch gallery", "game watch gallery") },
        saga("Lego") { keywords("lego") },
        saga("Disney") {
            sub("Serie principal", "disney princess", "disneys magical quest", "disney sports", "disneys magical mirror")
        },
    )

    /** Nombres de todas las sagas del catálogo, en orden alfabético, para el selector manual. */
    val sagaNames: List<String> by lazy { CATALOG.map { it.name }.sortedBy { it.lowercase() } }

    /** Subseries conocidas de una saga (para sugerir en el editor manual). */
    fun subseriesOf(saga: String): List<String> = CATALOG.firstOrNull { it.name == saga }
        ?.rules?.mapNotNull { it.subseries }?.distinct().orEmpty()

    /** Clasifica el nombre de archivo de una ROM. Rápido, local y reproducible. */
    fun classify(fileName: String): SagaMatch {
        val title = TitleNormalizer.displayTitle(fileName)
        val tokens = TitleNormalizer.tokens(title)
        val modifiedName = TitleNormalizer.looksModified(fileName)

        var bestSaga: Saga? = null
        var bestSize = 0
        var bestStart = Int.MAX_VALUE
        var bestMatches: List<Pair<Int, Rule>> = emptyList()
        for (saga in CATALOG) {
            val matches = ArrayList<Pair<Int, Rule>>()
            for (rule in saga.rules) {
                val at = indexOfPhrase(tokens, rule.phrase)
                if (at >= 0) matches.add(at to rule)
            }
            if (matches.isEmpty()) continue
            val size = matches.maxOf { it.second.phrase.size }
            val start = matches.filter { it.second.phrase.size == size }.minOf { it.first }
            if (size > bestSize || (size == bestSize && start < bestStart)) {
                bestSaga = saga
                bestSize = size
                bestStart = start
                bestMatches = matches
            }
        }

        if (bestSaga != null) {
            val covered = HashSet<Int>()
            for ((start, rule) in bestMatches) {
                for (offset in rule.phrase.indices) covered.add(start + offset)
            }
            // El nombre de la propia saga («The Legend of Zelda - …») no es texto extra.
            for (keyword in bestSaga.keywords) {
                val at = indexOfPhrase(tokens, keyword)
                if (at >= 0) for (offset in keyword.indices) covered.add(at + offset)
            }
            val leftover = tokens.indices.filter { index ->
                index !in covered && !isNoise(tokens[index])
            }
            val withSub = bestMatches.filter { it.second.subseries != null }
            val subseries = withSub.maxWithOrNull(
                compareBy<Pair<Int, Rule>> { it.second.phrase.size }.thenBy { -it.first },
            )?.second?.subseries
            val modified = modifiedName || bestMatches.any { it.second.modified }
            val confidence = if (leftover.isEmpty() && !modified) SagaConfidence.RELIABLE
            else SagaConfidence.PROBABLE
            return SagaMatch(bestSaga.name, subseries, confidence, title, modified)
        }

        // Sin títulos conocidos: solo una pista débil (la palabra clave de la saga).
        var weakSaga: Saga? = null
        var weakStart = Int.MAX_VALUE
        for (saga in CATALOG) {
            for (keyword in saga.keywords) {
                val at = indexOfPhrase(tokens, keyword)
                if (at >= 0 && at < weakStart) {
                    weakSaga = saga
                    weakStart = at
                }
            }
        }
        if (weakSaga != null) {
            val atStart = (0 until weakStart).all { tokens[it] in LEADING }
            return SagaMatch(
                saga = weakSaga.name,
                subseries = null,
                confidence = if (atStart) SagaConfidence.PROBABLE else SagaConfidence.DOUBTFUL,
                title = title,
                modified = modifiedName,
            )
        }
        return SagaMatch(null, null, SagaConfidence.DOUBTFUL, title, modifiedName)
    }

    private fun isNoise(token: String): Boolean =
        token in NOISE || token.all { it in '0'..'9' }

    private fun indexOfPhrase(tokens: List<String>, phrase: List<String>): Int {
        if (phrase.isEmpty() || phrase.size > tokens.size) return -1
        outer@ for (start in 0..tokens.size - phrase.size) {
            for (offset in phrase.indices) {
                if (tokens[start + offset] != phrase[offset]) continue@outer
            }
            return start
        }
        return -1
    }
}
