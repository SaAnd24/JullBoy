package com.ravenemu.shared.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import com.ravenemu.shared.about.AboutContent
import com.ravenemu.shared.about.DocumentReader
import com.ravenemu.shared.about.ReaderDocument
import com.ravenemu.shared.retro.RetroAchievementsContent
import com.ravenemu.shared.retro.RetroSnapshot
import com.ravenemu.shared.theme.RavenIcon
import com.ravenemu.shared.theme.RavenIconType

private val Background = Color(0xFF0A100D)
private val Surface = Color(0xFF131C17)
private val TextMain = Color(0xFFF2F7F3)
private val Muted = Color(0xFFA9B5AD)
private val Accent = Color(0xFF7DDC8E)
private val Outline = Color(0xFF2F4038)

private enum class Page(val label: String) {
    HOME("Paramètres"),
    RETRO("RetroAchievements"),
    GENERAL("Général"),
    GAME("Partida rápida"),
    AUDIO("Audio"),
    VIDEO("Vidéo"),
    CONSOLE("Console"),
    INTERFACE("Interface"),
    ABOUT("À propos"),
}

/** Shared RavenEmu 0.8.1-inspired settings navigation. Settings are supplied by the host. */
@Composable
fun SettingsScreen(
    settings: Settings,
    capabilities: SettingsCapabilities = SettingsCapabilities(),
    onSettingsChange: ((Settings) -> Unit)?,
    appVersion: String,
    onOpenLink: ((String) -> Unit)?,
    retroSnapshot: RetroSnapshot = RetroSnapshot(),
    retroImages: Map<String, androidx.compose.ui.graphics.ImageBitmap> = emptyMap(),
    retroBusy: Boolean = false,
    onRetroLogin: ((String, String) -> Unit)? = null,
    onRetroDisconnect: (() -> Unit)? = null,
    onRetroRetry: (() -> Unit)? = null,
    onRetroLeaderboard: ((Int, Boolean) -> Unit)? = null,
    hardcoreAvailable: Boolean = false,
    deltaSkins: List<DeltaSkinEntry> = emptyList(),
    onImportSkin: (() -> Unit)? = null,
    onToggleSkin: ((String) -> Unit)? = null,
    onDeleteSkin: ((String) -> Unit)? = null,
    gbaBiosInstalled: Boolean = false,
    onChooseGbaBios: (() -> Unit)? = null,
    onRemoveGbaBios: (() -> Unit)? = null,
    aboutOnly: Boolean,
    onBack: () -> Unit,
) {
    var page by remember(aboutOnly) {
        mutableStateOf(if (aboutOnly) Page.ABOUT else Page.HOME)
    }
    // A legal document or licence open in the reader, over the About page.
    var openDocument by remember { mutableStateOf<ReaderDocument?>(null) }
    val scroll = rememberScrollState()
    LaunchedEffect(openDocument) { scroll.scrollTo(0) }
    var skinToDelete by remember { mutableStateOf<DeltaSkinEntry?>(null) }
    val update: (Settings) -> Unit = { updated ->
        onSettingsChange?.invoke(updated.normalized())
    }
    Column(Modifier.fillMaxSize().background(Background)) {
        SettingsTopBar(openDocument?.title ?: page.label) {
            if (openDocument != null) openDocument = null
            else if (page == Page.HOME || aboutOnly) onBack()
            else page = Page.HOME
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(scroll)
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val reading = openDocument
            val editable = onSettingsChange != null
            if (reading != null) DocumentReader(reading) else when (page) {
                Page.HOME -> HomePage(onRetroLogin != null, capabilities) { page = it }
                Page.RETRO -> {
                    RetroAchievementsContent(
                        snapshot = retroSnapshot,
                        images = retroImages,
                        loginBusy = retroBusy,
                        onLogin = onRetroLogin,
                        onDisconnect = onRetroDisconnect,
                        onRetry = onRetroRetry,
                        onLeaderboard = onRetroLeaderboard,
                        onOpenLink = onOpenLink,
                    )
                    RetroSettings(settings, hardcoreAvailable, editable, update)
                }
                Page.GENERAL -> GeneralPage(settings, capabilities, editable, update)
                Page.GAME -> GamePage(settings, editable, update)
                Page.AUDIO -> AudioPage(settings, capabilities, editable, update)
                Page.VIDEO -> VideoPage(settings, capabilities, editable, update)
                Page.CONSOLE -> ConsolePage(settings, editable, update, gbaBiosInstalled, onChooseGbaBios, onRemoveGbaBios)
                Page.INTERFACE -> {
                    ControlsPage(settings, capabilities, editable, update)
                    if (capabilities.deltaSkins) {
                        DeltaSkinsSection(deltaSkins, onImportSkin, onToggleSkin, onDeleteSkin != null) {
                            skinToDelete = it
                        }
                    }
                }
                Page.ABOUT -> {
                    AboutContent(
                        onOpenLink = onOpenLink,
                        onOpenDocument = { openDocument = it },
                    )
                }
            }
        }
    }
    skinToDelete?.let { skin ->
        DeleteSkinDialog(skin, onConfirm = {
            onDeleteSkin?.invoke(skin.id)
            skinToDelete = null
        }, onDismiss = { skinToDelete = null })
    }
}

@Composable
private fun SettingsTopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(54.dp).background(Surface),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.size(48.dp),
        ) { Text("‹", color = TextMain, fontSize = 30.sp) }
        Text(title, color = TextMain, fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun HomePage(retroAvailable: Boolean, capabilities: SettingsCapabilities, onOpen: (Page) -> Unit) {
    if (retroAvailable) {
        CategoryRow("RetroAchievements", "Compte, succès et progression") {
            onOpen(Page.RETRO)
        }
    }
    CategoryRow("Général", when {
        capabilities.wirelessLink && capabilities.onlineCovers -> "Pause, câble link, jaquettes et diagnostics"
        capabilities.onlineCovers -> "Pause, jaquettes et diagnostics"
        else -> "Pause automatique"
    }) { onOpen(Page.GENERAL) }
    CategoryRow("Partida rápida", "Quick Save, avance rápido y autoguardado") { onOpen(Page.GAME) }
    CategoryRow("Audio", "Son du jeu et volume") { onOpen(Page.AUDIO) }
    CategoryRow("Vidéo", "Couleurs, correction LCD, mélange d'images, taille, luminosité et contraste") { onOpen(Page.VIDEO) }
    if (capabilities.console) {
        CategoryRow("Console", "Jeux Game Boy en couleurs, GBC d'une GBA, BIOS GBA") { onOpen(Page.CONSOLE) }
    }
    CategoryRow("Interface", if (capabilities.cartridgeHardware) "Vibrations, capteurs, commandes, retour arrière, style et Skin Delta" else "Commandes tactiles, retour arrière et style") { onOpen(Page.INTERFACE) }
    CategoryRow("À propos", "Version, auteur, confidentialité et licences") {
        onOpen(Page.ABOUT)
    }
}

/** How RetroAchievements notifies, and Hardcore once the app is approved. */
@Composable
private fun RetroSettings(settings: Settings, hardcoreAvailable: Boolean, editable: Boolean, update: (Settings) -> Unit) {
    GroupTitle("Notifications RetroAchievements")
    SettingSwitch("Déblocages et bilan", "Afficher les succès obtenus et le jeu terminé.",
        settings.retroUnlockPopups, editable) {
        update(settings.copy(retroUnlockPopups = it))
    }
    SettingSwitch("Progression des succès", "Afficher les hausses mesurées à tour de rôle.",
        settings.retroProgressPopups, editable) {
        update(settings.copy(retroProgressPopups = it))
    }
    SettingSwitch("Son des succès", "Un court carillon, créé par RavenEmu, joué avec le son du jeu pour chaque succès et le jeu terminé.",
        settings.retroPopupSound, editable) {
        update(settings.copy(retroPopupSound = it))
    }
    ChoiceRow("Popups en haut", settings.retroPopupPosition == "top", editable) {
        update(settings.copy(retroPopupPosition = "top"))
    }
    ChoiceRow("Popups en bas", settings.retroPopupPosition == "bottom", editable) {
        update(settings.copy(retroPopupPosition = "bottom"))
    }
    SettingSlider("Durée des déblocages", "${settings.retroPopupSeconds} s", settings.retroPopupSeconds,
        2..10, editable) { update(settings.copy(retroPopupSeconds = it)) }
    SettingSlider("Durée des progressions", "${settings.retroProgressSeconds} s", settings.retroProgressSeconds,
        1..5, editable) { update(settings.copy(retroProgressSeconds = it)) }
    if (!hardcoreAvailable) SettingDescription("Mode Hardcore indisponible",
        "L'activation attend la validation de RavenEmu par RetroAchievements. Le mode Softcore reste disponible.")
    if (hardcoreAvailable) {
        GroupTitle("Mode Hardcore")
        SettingSwitch(
            "Mode Hardcore",
            "Succès comptés en Hardcore. Le chargement des sauvegardes d'état est désactivé et les pauses sont limitées. L'activer redémarre le jeu en cours.",
            settings.retroHardcore,
            editable,
        ) { update(settings.copy(retroHardcore = it)) }
    }
}

@Composable
private fun GeneralPage(settings: Settings, capabilities: SettingsCapabilities, editable: Boolean, update: (Settings) -> Unit) {
    GroupTitle("Émulation")
    SettingDescription(
        "Pause automatique",
        "Le jeu et son audio sont suspendus lorsque RavenEmu passe en arrière-plan ou lorsque le panneau de jeu est ouvert. Ce comportement est fixe pour protéger la partie.",
    )
    if (capabilities.wirelessLink) {
        GroupTitle("Câble link")
        SettingSwitch(
            "Câble link sans fil",
            "Quand un jeu se sert de son câble link, RavenEmu cherche un autre téléphone sur le même réseau Wi-Fi et s'y relie tout seul. Le téléphone ne s'annonce sur le réseau local que pendant ce temps.",
            settings.wirelessLink,
            editable,
        ) { update(settings.copy(wirelessLink = it)) }
    }
    if (capabilities.onlineCovers) {
        GroupTitle("Bibliothèque")
        SettingSwitch(
            "Jaquettes en ligne",
            "Cherche les jaquettes manquantes sur thumbnails.libretro.com. Ce serveur tiers reçoit le nom des jeux de la bibliothèque et l'adresse IP de l'appareil.",
            settings.onlineCovers,
            editable,
        ) { update(settings.copy(onlineCovers = it)) }
    }
    if (capabilities.diagnostics) {
        GroupTitle("Diagnostic")
        SettingSwitch(
            "Afficher les performances",
            "FPS, temps du moteur et conversion vidéo dans le lecteur.",
            settings.showDiagnostics,
            editable,
        ) { update(settings.copy(showDiagnostics = it)) }
        Text("Le diagnostic audio reste exportable depuis le menu du jeu.",
            color = Muted, fontSize = 12.sp)
    }
}

/** JullBoy · estado rápido, avance rápido y protección de partidas. */
@Composable
private fun GamePage(settings: Settings, editable: Boolean, update: (Settings) -> Unit) {
    GroupTitle("Quick Save y Quick Load")
    SettingDescription(
        "Emplacement del estado rápido",
        "Quick Save y Quick Load usan uno de los cuatro emplacements de estado existentes, siempre del juego en curso. " +
            "Nunca tocan la partida normal del cartucho (.sav / .srm).",
    )
    for (slot in 0..3) {
        ChoiceRow("Emplacement ${slot + 1}", settings.quickSlot == slot, editable) {
            update(settings.copy(quickSlot = slot))
        }
    }
    GroupTitle("Avance rápido")
    SettingDescription(
        "Velocidad",
        "Cuántas imágenes del juego se calculan por cada una mostrada. «Máxima» es el límite del núcleo (8 imágenes); " +
            "la velocidad real depende de tu teléfono y de cada juego. El sonido pasa por trozos.",
    )
    for (speed in FAST_FORWARD_SPEEDS) {
        ChoiceRow(fastForwardLabel(speed), settings.fastForwardSpeed == speed, editable) {
            update(settings.copy(fastForwardSpeed = speed))
        }
    }
    SettingDescription(
        "Modo del botón »",
        "Alternar: un toque activa o desactiva. Mantener: acelera solo mientras tienes el botón pulsado.",
    )
    ChoiceRow("Alternar (activar / desactivar)", settings.fastForwardMode == "toggle", editable) {
        update(settings.copy(fastForwardMode = "toggle"))
    }
    ChoiceRow("Mantener pulsado", settings.fastForwardMode == "hold", editable) {
        update(settings.copy(fastForwardMode = "hold"))
    }
    Text(
        "Cada juego puede tener su propia velocidad desde el menú del juego; aquí se fija el valor global.",
        color = Muted, fontSize = 12.sp,
    )
    GroupTitle("Autoguardado")
    SettingSwitch(
        "Guardar el estado al salir",
        "Al salir del juego o enviar la app a segundo plano se guarda un estado de recuperación aparte " +
            "(no usa tus emplacements ni el .sav). Si la app se cierra de forma inesperada, JullBoy te " +
            "propone recuperar esa sesión al abrirse.",
        settings.autosave, editable,
    ) { update(settings.copy(autosave = it)) }
}

@Composable
private fun AudioPage(settings: Settings, capabilities: SettingsCapabilities, editable: Boolean, update: (Settings) -> Unit) {
    GroupTitle("Son du jeu")
    SettingSwitch(
        "Activer le son",
        "Conserve l'horloge d'émulation et coupe uniquement la sortie audio.",
        settings.audioEnabled,
        editable,
    ) { update(settings.copy(audioEnabled = it)) }
    SettingSlider(
        "Volume", "${settings.audioVolume} %",
        settings.audioVolume, 0..100,
        settings.audioEnabled && editable,
    ) { update(settings.copy(audioVolume = it)) }
    if (capabilities.audioStartupFade) Text("Le fondu de démarrage de 180 ms reste inchangé.",
        color = Muted, fontSize = 12.sp)
}

@Composable
private fun VideoPage(settings: Settings, capabilities: SettingsCapabilities, editable: Boolean, update: (Settings) -> Unit) {
    GroupTitle("Écran")
    SettingDescription(
        "Profil de couleurs",
        "Original préserve les couleurs actuelles ; DMG simule un LCD vert ; Pocket utilise le gris. Ces profils ne concernent que les jeux Game Boy : les jeux Game Boy Color et Game Boy Advance gardent toujours leurs couleurs.",
    )
    ChoiceRow("Original", settings.videoPalette == "original",
        editable) {
        update(settings.copy(videoPalette = "original"))
    }
    ChoiceRow("DMG vert", settings.videoPalette == "dmg",
        editable) {
        update(settings.copy(videoPalette = "dmg"))
    }
    ChoiceRow("Pocket gris", settings.videoPalette == "pocket",
        editable) {
        update(settings.copy(videoPalette = "pocket"))
    }
    GroupTitle("Correction des couleurs LCD")
    SettingSwitch(
        "Game Boy Color",
        "Atténue les couleurs très vives pour retrouver l'aspect plus mat de l'écran d'origine.",
        settings.lcdCorrectionGbc,
        editable,
    ) { update(settings.copy(lcdCorrectionGbc = it)) }
    SettingSwitch(
        "Game Boy Advance",
        "Même correction, réglée à part pour la Game Boy Advance.",
        settings.lcdCorrectionGba,
        editable,
    ) { update(settings.copy(lcdCorrectionGba = it)) }
    if (capabilities.frameBlending) FrameBlendingChoice(settings, editable, update)
    GroupTitle("Taille de l'image")
    SettingSwitch(
        "Pixels entiers",
        "L'image prend un multiple entier de sa taille : tous les pixels sont identiques, avec des bords noirs autour. Sans effet avec un skin Delta.",
        settings.integerScale,
        editable,
    ) { update(settings.copy(integerScale = it)) }
    GroupTitle("Ajustements")
    SettingSlider("Luminosité", "${settings.videoBrightness}",
        settings.videoBrightness, -50..50, editable) {
        update(settings.copy(videoBrightness = it))
    }
    SettingSlider("Contraste", "${settings.videoContrast} %",
        settings.videoContrast, 50..150, editable) {
        update(settings.copy(videoContrast = it))
    }
    TextButton(onClick = {
        update(settings.copy(
            videoPalette = "original", videoBrightness = 0, videoContrast = 100,
            lcdCorrectionGbc = false, lcdCorrectionGba = false,
            frameBlending = "off", integerScale = false,
        ))
    }, enabled = editable) {
        Text("Rétablir l'affichage d'origine", color = Accent)
    }
}

/** Mixing each image with the one before, for games that count on the slow LCD. */
@Composable
private fun FrameBlendingChoice(settings: Settings, editable: Boolean, update: (Settings) -> Unit) {
    GroupTitle("Mélange d'images")
    SettingDescription(
        "Rémanence de l'écran",
        "Certains jeux font clignoter un objet d'une image à l'autre pour le rendre transparent, en comptant sur la lenteur de l'écran d'origine (F-Zero, Castlevania). Le mélange le montre transparent ; la rémanence laisse une traîne.",
    )
    ChoiceRow("Désactivé (défaut)", settings.frameBlending == "off", editable) {
        update(settings.copy(frameBlending = "off"))
    }
    ChoiceRow("Mélange de deux images", settings.frameBlending == "mix", editable) {
        update(settings.copy(frameBlending = "mix"))
    }
    ChoiceRow("Rémanence", settings.frameBlending == "ghosting", editable) {
        update(settings.copy(frameBlending = "ghosting"))
    }
}

/** Holding ◀◀ plays the game backwards; off, the frames kept are freed. */
@Composable
private fun RewindSwitch(settings: Settings, editable: Boolean, update: (Settings) -> Unit) {
    GroupTitle("Retour arrière")
    SettingSwitch(
        "Retour arrière",
        "Maintenez le bouton ◀◀ en haut du lecteur, ou le clic du stick gauche de la manette, pour rejouer les dernières minutes à l'envers. Garde jusqu'à 32 Mo d'images. Indisponible en mode Hardcore et pendant le câble sans fil.",
        settings.rewind,
        editable,
    ) { update(settings.copy(rewind = it)) }
}

/**
 * The console that runs the games: Game Boy games on a GBC and their colors,
 * the GBC of a GBA, and the GBA BIOS. All taken at the game's launch, except
 * the colors, which change at once.
 */
@Composable
private fun ConsolePage(
    settings: Settings, editable: Boolean, update: (Settings) -> Unit,
    gbaBiosInstalled: Boolean, onChooseGbaBios: (() -> Unit)?, onRemoveGbaBios: (() -> Unit)?,
) {
    GroupTitle("Game Boy et Game Boy Color")
    SettingSwitch(
        "Jeux Game Boy en couleurs",
        "Les jeux Game Boy tournent sur une Game Boy Color, qui leur donne des couleurs : celles que sa boot ROM choisit pour chaque jeu (Pokémon Rouge en rouge, Bleu en bleu…), ou celles choisies ci-dessous. Un état pris dans l'autre mode ne se recharge pas. Pris en compte au lancement du jeu.",
        settings.gbInColor,
        editable,
    ) { update(settings.copy(gbInColor = it)) }
    SettingDescription(
        "Couleurs des jeux Game Boy",
        "Les combinaisons sont celles que l'on tenait pendant le logo de la console. Changées aussitôt, même en jeu.",
    )
    GB_COLORS.forEachIndexed { index, label ->
        ChoiceRow(label, settings.gbColors == index, editable && settings.gbInColor) {
            update(settings.copy(gbColors = index))
        }
    }
    SettingSwitch(
        "Game Boy Color d'une Game Boy Advance",
        "La GBC intégrée à une Game Boy Advance : des jeux comme Zelda Oracle ou Shantae débloquent alors leurs bonus. Un état pris avec l'autre console ne se recharge pas. Pris en compte au lancement du jeu.",
        settings.gbcOnGba,
        editable,
    ) { update(settings.copy(gbcOnGba = it)) }
    GroupTitle("Game Boy Advance")
    SettingDescription(
        "BIOS",
        "RavenCore répond lui-même aux appels du BIOS. Le vrai BIOS, celui de votre console, joue son animation de démarrage (sauf si vous la sautez) : choisissez son fichier (16 Kio), aucun BIOS n'est fourni. Un état ne se recharge qu'avec le BIOS qui l'a créé. Pris en compte au lancement du jeu.",
    )
    ChoiceRow("BIOS de RavenCore (défaut)", settings.gbaBios == 0, editable) { update(settings.copy(gbaBios = 0)) }
    ChoiceRow("Vrai BIOS", settings.gbaBios == 1, editable) { update(settings.copy(gbaBios = 1)) }
    ChoiceRow("Vrai BIOS, sans animation", settings.gbaBios == 2, editable) { update(settings.copy(gbaBios = 2)) }
    Text(
        if (gbaBiosInstalled) "Fichier du BIOS : installé" else "Fichier du BIOS : absent",
        color = if (gbaBiosInstalled) TextMain else Muted, fontSize = 13.sp,
    )
    if (onChooseGbaBios != null) {
        TextButton(onClick = onChooseGbaBios, enabled = editable) {
            Text(if (gbaBiosInstalled) "Remplacer le fichier du BIOS" else "Choisir le fichier du BIOS", color = Accent)
        }
    }
    if (gbaBiosInstalled && onRemoveGbaBios != null) {
        TextButton(onClick = onRemoveGbaBios, enabled = editable) { Text("Retirer le fichier du BIOS", color = Muted) }
    }
}

/** Touch controls, their style, and the cartridge hardware the phone stands in for. */
@Composable
private fun ControlsPage(settings: Settings, capabilities: SettingsCapabilities, editable: Boolean, update: (Settings) -> Unit) {
    GroupTitle("Commandes tactiles")
    if (capabilities.haptics) {
        SettingSwitch(
            "Retour haptique",
            "Petite vibration à la pression des boutons.",
            settings.haptics,
            editable,
        ) { update(settings.copy(haptics = it)) }
    }
    if (capabilities.cartridgeHardware) {
        SettingSwitch(
            "Vibration de la cartouche",
            "Fait vibrer le téléphone avec les jeux équipés d'un moteur de vibration (Drill Dozer, WarioWare: Twisted!, cartouches Game Boy Rumble).",
            settings.cartridgeRumble,
            editable,
        ) { update(settings.copy(cartridgeRumble = it)) }
    }
    SettingSlider(
        "Taille des commandes", "${settings.controlsScale} %",
        settings.controlsScale, 80..115, editable,
    ) { update(settings.copy(controlsScale = it)) }
    SettingSlider(
        "Espacement vertical", "${settings.controlsGap} dp",
        settings.controlsGap, 20..80, editable,
    ) { update(settings.copy(controlsGap = it)) }
    GroupTitle("Style des boutons")
    ChoiceRow("Classique (défaut)", settings.controlsStyle == "classic",
        editable) {
        update(settings.copy(controlsStyle = "classic"))
    }
    ChoiceRow("Contraste élevé", settings.controlsStyle == "contrast",
        editable) {
        update(settings.copy(controlsStyle = "contrast"))
    }
    Text("Le déplacement libre des boutons sera ajouté plus tard.",
        color = Muted, fontSize = 12.sp)
    if (capabilities.rewind) RewindSwitch(settings, editable, update)
    TextButton(onClick = {
        update(settings.copy(
            haptics = false, controlsScale = 100,
            controlsGap = 46, controlsStyle = "classic",
        ))
    }, enabled = editable) {
        Text("Réinitialiser les commandes", color = Accent)
    }
    if (capabilities.cartridgeHardware) {
        GroupTitle("Capteurs de la cartouche")
        SettingSwitch(
            "Capteurs du téléphone",
            "Le gyroscope, l'inclinaison et la lumière du téléphone remplacent ceux de la cartouche : WarioWare: Twisted!, Yoshi Topsy-Turvy, Kirby Tilt 'n' Tumble, Boktai.",
            settings.cartridgeSensors,
            editable,
        ) { update(settings.copy(cartridgeSensors = it)) }
        SettingSwitch(
            "Soleil automatique (Boktai)",
            "Le capteur de lumière du téléphone règle le soleil : il faut la lumière du jour, celle d'une pièce ne suffit pas. Sans ce capteur, le niveau ci-dessous s'applique.",
            settings.solarLightAuto,
            editable && settings.cartridgeSensors,
        ) { update(settings.copy(solarLightAuto = it)) }
        SettingSlider(
            "Soleil (Boktai)", "${settings.solarLightLevel} %",
            settings.solarLightLevel, 0..100,
            editable && !(settings.cartridgeSensors && settings.solarLightAuto),
        ) { update(settings.copy(solarLightLevel = (it + 5) / 10 * 10)) }
    }
}

@Composable
private fun DeltaSkinsSection(
    deltaSkins: List<DeltaSkinEntry>,
    onImportSkin: (() -> Unit)?,
    onToggleSkin: ((String) -> Unit)?,
    deleteEnabled: Boolean,
    onDelete: (DeltaSkinEntry) -> Unit,
) {
    GroupTitle("Skin Delta")
    Text(
        "RavenEmu lit les skins au format .deltaskin, en portrait. Ce projet n'est ni affilié à Delta, ni approuvé par ses auteurs : aucun skin n'est fourni, vous importez les vôtres.",
        color = Muted, fontSize = 12.sp,
    )
    TextButton(onClick = { onImportSkin?.invoke() }, enabled = onImportSkin != null) {
        Text("Importer un fichier .deltaskin", color = Accent)
    }
    if (deltaSkins.isEmpty()) {
        Text("Aucun skin installé : commandes classiques.", color = Muted, fontSize = 12.sp)
    }
    for (skin in deltaSkins) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(skin.name, color = TextMain, fontSize = 14.sp,
                    fontWeight = FontWeight.Medium)
                Text(skin.console + if (skin.selected) " · utilisé" else "",
                    color = if (skin.selected) Accent else Muted, fontSize = 12.sp)
            }
            TextButton(onClick = { onToggleSkin?.invoke(skin.id) }, enabled = onToggleSkin != null) {
                Text(if (skin.selected) "Retirer" else "Utiliser", color = Accent, fontSize = 13.sp)
            }
            TextButton(onClick = { onDelete(skin) }, enabled = deleteEnabled) {
                Text("Supprimer", color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun DeleteSkinDialog(skin: DeltaSkinEntry, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Supprimer ce skin ?") },
        text = { Text("${skin.name} sera supprimé de l'appareil. Les commandes classiques reviennent s'il était utilisé.") },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text("Supprimer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

@Composable
private fun GroupTitle(title: String) {
    Text(title, color = Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    HorizontalDivider(color = Outline)
}

@Composable
private fun CategoryRow(title: String, summary: String, onClick: () -> Unit) {
    val icon = when (title) {
        "RetroAchievements" -> RavenIconType.RETROACHIEVEMENTS
        "Général" -> RavenIconType.GENERAL
        "Audio" -> RavenIconType.AUDIO
        "Vidéo" -> RavenIconType.VIDEO
        "Interface", "Partida rápida" -> RavenIconType.INTERFACE
        else -> RavenIconType.ABOUT
    }
    Row(
        Modifier.fillMaxWidth()
            .border(1.dp, Outline.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
            .background(Surface, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        androidx.compose.foundation.layout.Box(
            Modifier.size(42.dp)
                .background(Accent.copy(alpha = 0.13f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) { RavenIcon(icon, Accent) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = TextMain, fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold)
            Text(summary, color = Muted, fontSize = 12.sp)
        }
        Text("›", color = Accent, fontSize = 23.sp)
    }
}

@Composable
private fun SettingDescription(title: String, summary: String) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = TextMain, fontSize = 15.sp)
        Text(summary, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun SettingSwitch(
    title: String, summary: String, checked: Boolean, enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            SettingDescription(title, summary)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange, enabled = enabled)
    }
}

@Composable
private fun SettingSlider(
    title: String, valueText: String, value: Int, range: IntRange,
    enabled: Boolean, onChange: (Int) -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = TextMain, fontSize = 15.sp)
            Text(valueText, color = Accent, fontSize = 14.sp)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            enabled = enabled,
        )
    }
}

@Composable
private fun ChoiceRow(
    title: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit,
) {
    Row(Modifier.fillMaxWidth().background(if (selected) Surface else Background)
        .clickable(enabled = enabled, onClick = onClick)
        .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(if (selected) "●" else "○", color = Accent, fontSize = 17.sp)
        Spacer(Modifier.width(12.dp))
        Text(title, color = TextMain, fontSize = 14.sp)
    }
}

