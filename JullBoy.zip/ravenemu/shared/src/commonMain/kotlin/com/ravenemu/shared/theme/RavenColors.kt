package com.ravenemu.shared.theme

import androidx.compose.ui.graphics.Color

/*
 * RavenEmu 0.8.1 visual reference:
 * app/android/src/main/res/layout/activity_main.xml
 * app/android/src/main/res/layout/item_rom_grid.xml
 * app/android/src/main/res/values/colors.xml
 *
 * Reimplemented with shared Compose so Android and iOS show the same screens.
 */
internal val RavenBackground = Color(0xFF0A100D)
internal val RavenSurface = Color(0xFF131C17)
internal val RavenAccent = Color(0xFF7DDC8E)
internal val RavenText = Color(0xFFF2F7F3)
internal val RavenSecondary = Color(0xFFC9D3CC)
internal val RavenMuted = Color(0xFFA9B5AD)
internal val RavenOutline = Color(0xFF2F4038)
internal val RavenDanger = Color(0xFFFF928B)
/** Unlocks and completed games, as on the PC banner. */
internal val RavenGold = Color(0xFFF4C152)
