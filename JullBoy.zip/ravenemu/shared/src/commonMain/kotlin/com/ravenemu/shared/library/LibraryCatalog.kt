package com.ravenemu.shared.library

enum class GamePlatform { GB, GBC, GBA }

data class GameEntry(
    val id: String,
    /** El nombre de archivo del juego: la consola se deduce de él y el motor lo recibe tal cual. */
    val title: String,
    val platform: GamePlatform,
    /** Lo que muestran las pantallas: título limpio o editado. Por defecto, [title]. */
    val displayTitle: String = title,
    /** Cuándo entró el juego en la biblioteca (ms desde 1970); 0 si se desconoce. */
    val addedAt: Long = 0L,
)

object LibraryCatalog {
    fun search(
        games: List<GameEntry>,
        query: String,
        platform: GamePlatform?,
    ): List<GameEntry> {
        val needle = query.trim()
        return games.filter { game ->
            (platform == null || game.platform == platform) &&
                (needle.isEmpty() ||
                    game.title.contains(needle, ignoreCase = true) ||
                    game.displayTitle.contains(needle, ignoreCase = true))
        }
    }
}
