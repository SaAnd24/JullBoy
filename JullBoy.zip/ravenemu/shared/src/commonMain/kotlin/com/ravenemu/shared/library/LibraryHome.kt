package com.ravenemu.shared.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ravenemu.shared.theme.RavenAccent
import com.ravenemu.shared.theme.RavenBackground
import com.ravenemu.shared.theme.RavenDanger
import com.ravenemu.shared.theme.RavenMuted
import com.ravenemu.shared.theme.RavenOutline
import com.ravenemu.shared.theme.RavenSecondary
import com.ravenemu.shared.theme.RavenSurface
import com.ravenemu.shared.theme.RavenText

/* JullBoy · inicio y organización de la biblioteca. Todo es virtual: nada mueve ni renombra ROM. */

/** Una colección elegida en la fila de chips; null es la vista normal por consolas. */
@Composable
internal fun CollectionChips(
    collections: List<LibraryCollection>,
    selectedId: String?,
    onSelect: (String?) -> Unit,
) {
    LazyRow(
        Modifier.fillMaxWidth().padding(bottom = 6.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item(key = "all") { Chip("Consolas", selectedId == null) { onSelect(null) } }
        items(collections, key = { it.id }) { collection ->
            Chip("${collection.title} · ${collection.gameIds.size}", selectedId == collection.id) {
                onSelect(collection.id)
            }
        }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box40(selected, onClick) {
        Text(
            text,
            color = if (selected) RavenBackground else RavenText,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun Box40(selected: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.Box(
        Modifier.height(40.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) RavenAccent else RavenSurface)
            .semantics { role = Role.Tab }
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) { content() }
}

/** «Continuar jugando» y «Favoritos»: arrancar una partida en un toque desde el inicio. */
@Composable
internal fun HomeStrips(
    continuePlaying: List<GameEntry>,
    favorites: List<GameEntry>,
    covers: Map<String, ImageBitmap>,
    onSelect: (GameEntry) -> Unit,
) {
    if (continuePlaying.isEmpty() && favorites.isEmpty()) return
    Column(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (continuePlaying.isNotEmpty()) Strip("Continuar jugando", continuePlaying, covers, onSelect)
        if (favorites.isNotEmpty()) Strip("★ Favoritos", favorites, covers, onSelect)
    }
}

@Composable
private fun Strip(title: String, entries: List<GameEntry>, covers: Map<String, ImageBitmap>, onSelect: (GameEntry) -> Unit) {
    Text(title, color = RavenSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 16.dp, top = 4.dp), letterSpacing = 0.6.sp)
    LazyRow(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(entries, key = { it.id }) { entry ->
            Column(
                Modifier.width(78.dp).clip(RoundedCornerShape(10.dp)).clickable { onSelect(entry) }
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                CoverArtwork(entry.platform, covers[entry.id], Modifier.width(66.dp).height(66.dp))
                Text(entry.displayTitle, color = RavenSecondary, fontSize = 10.sp, lineHeight = 12.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            }
        }
    }
}

/** Ofrece recuperar la última sesión tras un cierre inesperado. */
@Composable
internal fun RecoveryDialog(title: String, savedAt: String, onRecover: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("¿Recuperar la última sesión?") },
        text = {
            Text(
                "JullBoy no se cerró con normalidad mientras jugabas a «$title». Hay un autoguardado" +
                    (if (savedAt.isNotBlank()) " del $savedAt" else "") +
                    ". Recuperarlo carga ese estado; tu guardado normal del cartucho y tus emplacements no se tocan.",
            )
        },
        confirmButton = { TextButton(onClick = onRecover) { Text("Recuperar", color = RavenAccent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Ahora no", color = RavenSecondary) } },
        containerColor = RavenSurface, titleContentColor = RavenText, textContentColor = RavenSecondary,
    )
}

@Composable
internal fun TextPromptDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    extraLabel: String? = null,
    onExtra: (() -> Unit)? = null,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(value = text, onValueChange = { text = it.take(120) }, singleLine = true,
                modifier = Modifier.fillMaxWidth())
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) {
                Text(confirmLabel, color = RavenAccent)
            }
        },
        dismissButton = {
            Row {
                if (extraLabel != null && onExtra != null) {
                    TextButton(onClick = onExtra) { Text(extraLabel, color = RavenSecondary) }
                }
                TextButton(onClick = onDismiss) { Text("Cancelar", color = RavenSecondary) }
            }
        },
        containerColor = RavenSurface, titleContentColor = RavenText, textContentColor = RavenText,
    )
}

@Composable
private fun SagaPickerDialog(current: String?, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val needle = query.trim()
    val matches = SagaCatalog.sagaNames.filter { needle.isEmpty() || it.contains(needle, ignoreCase = true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Elegir saga") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(value = query, onValueChange = { query = it.take(60) }, singleLine = true,
                    placeholder = { Text("Buscar o escribir una saga nueva") }, modifier = Modifier.fillMaxWidth())
                Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) {
                    if (needle.isNotEmpty() && matches.none { it.equals(needle, ignoreCase = true) }) {
                        PickRow("Crear saga «$needle»", false) { onPick(needle) }
                    }
                    for (name in matches) PickRow(name, name == current) { onPick(name) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = RavenSecondary) } },
        containerColor = RavenSurface, titleContentColor = RavenText, textContentColor = RavenText,
    )
}

@Composable
private fun PickRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(44.dp).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(if (selected) "● " else "○ ", color = RavenAccent, fontSize = 14.sp)
        Text(text, color = RavenText, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ConfirmDialog(title: String, message: String, confirm: String, danger: Boolean, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirm, color = if (danger) RavenDanger else RavenAccent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = RavenSecondary) } },
        containerColor = RavenSurface, titleContentColor = RavenText, textContentColor = RavenSecondary,
    )
}

private enum class OrganizeDialog { NONE, RENAME, SAGA, REMOVE, NEW_COLLECTION }

/**
 * Hoja de organización de un juego: favorito, título, saga, colecciones, copias de la partida y
 * retirada de la biblioteca. Cada botón hace algo real y ninguno toca los archivos originales.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun GameOrganizeSheet(
    entry: GameEntry,
    organization: LibraryOrganization,
    busy: Boolean,
    onDismiss: () -> Unit,
) {
    val meta = organization.metas[entry.id]
    val classification = SmartCollections.classify(entry, meta)
    var dialog by remember { mutableStateOf(OrganizeDialog.NONE) }
    var restoring by remember { mutableStateOf<SaveBackupInfo?>(null) }
    val backups = remember(entry.id, busy) { organization.onListBackups(entry.id) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = RavenSurface,
        contentColor = RavenText,
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Organizar", color = RavenMuted, fontSize = 12.sp, letterSpacing = 0.8.sp)
            Text(classification.title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("Archivo: ${entry.title}", color = RavenMuted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(classificationText(classification), color = RavenSecondary, fontSize = 13.sp)

            ToggleRow("★ Favorito", meta?.favorite == true) { organization.onToggleFavorite(entry.id) }
            ToggleRow("Marcado como terminado", meta?.completed == true) { organization.onToggleCompleted(entry.id) }
            ToggleRow("Es un hack o una traducción", classification.modified) { organization.onToggleHack(entry.id) }

            Text("Clasificación", color = RavenText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { dialog = OrganizeDialog.RENAME }, modifier = Modifier.weight(1f)) {
                    Text("Editar título", fontSize = 12.sp)
                }
                OutlinedButton(onClick = { dialog = OrganizeDialog.SAGA }, modifier = Modifier.weight(1f)) {
                    Text("Cambiar saga", fontSize = 12.sp)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { organization.onIgnoreSaga(entry.id) },
                    enabled = classification.saga != null && classification.source != ClassificationSource.IGNORED,
                    modifier = Modifier.weight(1f),
                ) { Text("Ignorar detección", fontSize = 12.sp) }
                OutlinedButton(
                    onClick = { organization.onResetClassification(entry.id) },
                    enabled = meta?.hasManualClassification == true,
                    modifier = Modifier.weight(1f),
                ) { Text("Restablecer", fontSize = 12.sp) }
            }
            Text(
                "Tus correcciones se guardan por juego: los próximos escaneos no las repiten ni las pisan.",
                color = RavenMuted, fontSize = 12.sp, lineHeight = 16.sp,
            )

            Text("Colecciones", color = RavenText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            if (organization.customCollections.isEmpty()) {
                Text("Aún no tienes colecciones propias. Un juego puede estar en varias a la vez.",
                    color = RavenMuted, fontSize = 12.sp)
            }
            for (collection in organization.customCollections) {
                ToggleRow(collection.name, meta?.collections?.contains(collection.id) == true) {
                    organization.onToggleInCollection(entry.id, collection.id)
                }
            }
            OutlinedButton(onClick = { dialog = OrganizeDialog.NEW_COLLECTION }, modifier = Modifier.fillMaxWidth()) {
                Text("Nueva colección…")
            }

            Text("Copias de la partida", color = RavenText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            if (backups.isEmpty()) {
                Text(
                    "Todavía no hay copias. JullBoy guarda una antes de abrir el juego cuando su partida normal ha cambiado.",
                    color = RavenMuted, fontSize = 12.sp, lineHeight = 16.sp,
                )
            } else {
                for (backup in backups) {
                    Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            (if (backup.index == 1) "Más reciente · " else "Anterior · ") +
                                organization.formatTime(backup.savedAt),
                            color = RavenSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { restoring = backup }, enabled = !busy) {
                            Text("Restaurar", color = RavenAccent)
                        }
                    }
                }
            }

            Spacer(Modifier.height(4.dp))
            OutlinedButton(
                onClick = { dialog = OrganizeDialog.REMOVE },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Retirar de la biblioteca", color = RavenDanger) }
            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = RavenAccent, contentColor = RavenBackground),
            ) { Text("Listo") }
        }
    }

    when (dialog) {
        OrganizeDialog.RENAME -> TextPromptDialog(
            title = "Editar título",
            initial = classification.title,
            confirmLabel = "Guardar",
            extraLabel = if (meta?.titleOverride != null) "Título automático" else null,
            onExtra = { organization.onRename(entry.id, null); dialog = OrganizeDialog.NONE },
            onConfirm = { organization.onRename(entry.id, it); dialog = OrganizeDialog.NONE },
            onDismiss = { dialog = OrganizeDialog.NONE },
        )
        OrganizeDialog.SAGA -> SagaPickerDialog(
            current = classification.saga,
            onPick = { organization.onSetSaga(entry.id, it); dialog = OrganizeDialog.NONE },
            onDismiss = { dialog = OrganizeDialog.NONE },
        )
        OrganizeDialog.NEW_COLLECTION -> TextPromptDialog(
            title = "Nueva colección",
            initial = "",
            confirmLabel = "Crear",
            onConfirm = { organization.onCreateCollection(it); dialog = OrganizeDialog.NONE },
            onDismiss = { dialog = OrganizeDialog.NONE },
        )
        OrganizeDialog.REMOVE -> ConfirmDialog(
            title = "¿Retirar de la biblioteca?",
            message = "Se borra solo la copia de la ROM que JullBoy guarda en su espacio privado. Tus archivos " +
                "originales, tus partidas y tus estados no se tocan: si vuelves a importarla, sigues donde lo dejaste.",
            confirm = "Retirar", danger = true,
            onConfirm = {
                dialog = OrganizeDialog.NONE
                organization.onRemoveGame(entry.id)
                onDismiss()
            },
            onDismiss = { dialog = OrganizeDialog.NONE },
        )
        OrganizeDialog.NONE -> Unit
    }
    restoring?.let { backup ->
        ConfirmDialog(
            title = "¿Restaurar esta copia?",
            message = "Se restaura la partida normal del cartucho (.sav) del ${organization.formatTime(backup.savedAt)}. " +
                "La partida actual se guarda antes como otra copia, así que no se pierde. Tus estados rápidos no cambian.",
            confirm = "Restaurar", danger = false,
            onConfirm = { restoring = null; organization.onRestoreBackup(entry.id, backup.index) },
            onDismiss = { restoring = null },
        )
    }
}

private fun classificationText(c: GameClassification): String = when (c.source) {
    ClassificationSource.MANUAL -> "Saga: ${c.saga} · elegida por ti"
    ClassificationSource.IGNORED -> "Sin clasificar · detección ignorada por ti"
    ClassificationSource.NONE ->
        if (c.suggestion != null) "Sin clasificar · ¿quizá ${c.suggestion}? Puedes asignarla a mano."
        else "Sin clasificar · no se reconoce el título."
    ClassificationSource.AUTO -> {
        val sub = c.subseries?.let { " · $it" } ?: ""
        val how = if (c.confidence == SagaConfidence.RELIABLE) "detección fiable" else "detección probable, revísala"
        "Saga: ${c.saga}$sub ($how)" + if (c.modified) " · hack o traducción" else ""
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(48.dp).clickable(onClick = onChange)
            .semantics { contentDescription = label },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = RavenText, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = { onChange() })
    }
}

/** Carpetas guardadas para volver a escanear, con la opción de olvidarlas. */
@Composable
internal fun FoldersDialog(
    folders: List<LibraryFolder>,
    onRemove: (String) -> Unit,
    onRescan: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Carpetas de la biblioteca") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (folders.isEmpty()) {
                    Text("Aún no has guardado ninguna carpeta. Con «Importar un dossier» eliges una y JullBoy la recordará " +
                        "para poder escanearla de nuevo sin copiar otra vez lo que no cambió.")
                } else {
                    Text("JullBoy solo tiene permiso de lectura sobre estas carpetas. Olvidar una no borra nada.",
                        color = RavenMuted, fontSize = 12.sp)
                }
                for (folder in folders) {
                    Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(folder.label, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        TextButton(onClick = { onRemove(folder.id) }) { Text("Olvidar", color = RavenDanger) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onDismiss(); onRescan() }, enabled = folders.isNotEmpty()) {
                Text("Escanear ahora", color = RavenAccent)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cerrar", color = RavenSecondary) } },
        containerColor = RavenSurface, titleContentColor = RavenText, textContentColor = RavenText,
    )
}
