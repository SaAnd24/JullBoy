package com.ravenemu.shared.library

/**
 * JullBoy · organización virtual de la biblioteca.
 *
 * Nada de esto mueve, renombra ni duplica archivos ROM, ni toca los datos de guardado:
 * son solo datos de presentación asociados a cada juego por su huella SHA-256 (el `id`).
 * Código común (Android e iOS): sin API de la JVM.
 */

/** Lo que el usuario ha decidido (o se ha jugado) de un juego. Se guarda por huella de ROM. */
data class GameMeta(
    val favorite: Boolean = false,
    /** Última partida, en milisegundos desde 1970; 0 si nunca se ha jugado. */
    val lastPlayedAt: Long = 0L,
    val playCount: Int = 0,
    /** Título editado a mano; null para usar el título limpio automático. */
    val titleOverride: String? = null,
    /** Saga elegida a mano; gana siempre sobre la detección automática. */
    val sagaOverride: String? = null,
    /** El usuario descartó la detección automática: el juego queda «Sin clasificar». */
    val sagaIgnored: Boolean = false,
    /** Marca manual de hack/traducción; null para fiarse de la detección por nombre. */
    val hackOverride: Boolean? = null,
    /** Marcado a mano como terminado (el emulador no puede saberlo con fiabilidad). */
    val completed: Boolean = false,
    /** Identificadores de colecciones personalizadas a las que pertenece. */
    val collections: Set<String> = emptySet(),
) {
    /** ¿Tiene alguna corrección manual de clasificación? */
    val hasManualClassification: Boolean
        get() = sagaOverride != null || sagaIgnored || titleOverride != null || hackOverride != null
}

/** Una colección creada por el usuario. */
data class CustomCollection(val id: String, val name: String)

/** Una copia rotativa del guardado normal de un juego (1 es la más reciente). */
data class SaveBackupInfo(val index: Int, val savedAt: Long, val bytes: Int)

/** Una carpeta autorizada con el selector de Android, para volver a escanearla. */
data class LibraryFolder(val id: String, val label: String)

enum class LibrarySort(val label: String) {
    TITLE("A-Z"),
    LAST_PLAYED("Última partida"),
    ADDED("Añadidos"),
}

enum class ClassificationSource { AUTO, MANUAL, IGNORED, NONE }

/** La clasificación efectiva de un juego: detección automática más las correcciones del usuario. */
data class GameClassification(
    val title: String,
    val saga: String?,
    val subseries: String?,
    val confidence: SagaConfidence?,
    val source: ClassificationSource,
    val modified: Boolean,
    /** Una saga posible pero demasiado dudosa para asignarla sola. */
    val suggestion: String? = null,
) {
    /** Asignada automáticamente pero revisable. */
    val needsReview: Boolean
        get() = source == ClassificationSource.AUTO && confidence == SagaConfidence.PROBABLE
}

enum class CollectionKind { SMART, SAGA, CUSTOM }

data class LibraryCollection(
    val id: String,
    val title: String,
    val kind: CollectionKind,
    val gameIds: Set<String>,
)

/** Las colecciones virtuales y su cálculo. Funciones puras y probadas. */
object SmartCollections {
    const val FAVORITES = "fav"
    const val RECENT = "recent"
    const val UNPLAYED = "unplayed"
    const val UNFINISHED = "unfinished"
    const val HACKS = "hacks"
    const val UNCLASSIFIED = "unclassified"
    const val SAGA_PREFIX = "saga:"
    const val CUSTOM_PREFIX = "custom:"

    /** Cuántas partidas recientes se muestran. */
    const val RECENT_LIMIT = 30

    fun sagaId(saga: String): String = SAGA_PREFIX + saga

    fun customId(id: String): String = CUSTOM_PREFIX + id

    fun classify(entry: GameEntry, meta: GameMeta?): GameClassification {
        val auto = SagaCatalog.classify(entry.title)
        val title = meta?.titleOverride?.takeIf { it.isNotBlank() } ?: auto.title
        val modified = meta?.hackOverride ?: auto.modified
        val override = meta?.sagaOverride?.takeIf { it.isNotBlank() }
        return when {
            override != null -> GameClassification(
                title, override, null, SagaConfidence.RELIABLE, ClassificationSource.MANUAL, modified,
            )
            meta?.sagaIgnored == true -> GameClassification(
                title, null, null, null, ClassificationSource.IGNORED, modified,
            )
            auto.saga == null || auto.confidence == SagaConfidence.DOUBTFUL -> GameClassification(
                title, null, null, null, ClassificationSource.NONE, modified, suggestion = auto.saga,
            )
            else -> GameClassification(
                title, auto.saga, auto.subseries, auto.confidence, ClassificationSource.AUTO, modified,
            )
        }
    }

    /** El título que se muestra para [entry]. */
    fun displayTitle(entry: GameEntry, meta: GameMeta?): String = classify(entry, meta).title

    /**
     * Todas las colecciones no vacías: inteligentes, sagas (con al menos dos juegos, o con alguno
     * asignado a mano) y personalizadas. Un juego puede estar en varias a la vez.
     */
    fun build(
        entries: List<GameEntry>,
        metas: Map<String, GameMeta>,
        custom: List<CustomCollection>,
    ): List<LibraryCollection> {
        val favorites = LinkedHashSet<String>()
        val unplayed = LinkedHashSet<String>()
        val unfinished = LinkedHashSet<String>()
        val hacks = LinkedHashSet<String>()
        val unclassified = LinkedHashSet<String>()
        val recent = ArrayList<Pair<Long, String>>()
        val sagas = LinkedHashMap<String, LinkedHashSet<String>>()
        val manualSagas = HashSet<String>()
        val customMembers = LinkedHashMap<String, LinkedHashSet<String>>()
        for (collection in custom) customMembers[collection.id] = LinkedHashSet()

        for (entry in entries) {
            val meta = metas[entry.id]
            val classification = classify(entry, meta)
            if (meta?.favorite == true) favorites.add(entry.id)
            if (meta == null || meta.lastPlayedAt <= 0L) unplayed.add(entry.id)
            else {
                recent.add(meta.lastPlayedAt to entry.id)
                if (!meta.completed) unfinished.add(entry.id)
            }
            if (classification.modified) hacks.add(entry.id)
            val saga = classification.saga
            if (saga == null) {
                unclassified.add(entry.id)
            } else {
                sagas.getOrPut(saga) { LinkedHashSet() }.add(entry.id)
                if (classification.source == ClassificationSource.MANUAL) manualSagas.add(saga)
            }
            meta?.collections?.forEach { id -> customMembers[id]?.add(entry.id) }
        }

        val result = ArrayList<LibraryCollection>()
        fun smart(id: String, title: String, ids: Set<String>) {
            if (ids.isNotEmpty()) result.add(LibraryCollection(id, title, CollectionKind.SMART, ids))
        }
        smart(FAVORITES, "Favoritos", favorites)
        smart(
            RECENT, "Jugados recientemente",
            recent.sortedByDescending { it.first }.take(RECENT_LIMIT).map { it.second }.toSet(),
        )
        smart(UNPLAYED, "Nunca jugados", unplayed)
        smart(UNFINISHED, "Sin terminar", unfinished)
        smart(HACKS, "Hacks y traducciones", hacks)
        smart(UNCLASSIFIED, "Sin clasificar", unclassified)
        sagas.entries
            .filter { it.value.size >= 2 || it.key in manualSagas }
            .sortedWith(compareByDescending<Map.Entry<String, LinkedHashSet<String>>> { it.value.size }
                .thenBy { it.key.lowercase() })
            .forEach { (name, ids) ->
                result.add(LibraryCollection(sagaId(name), name, CollectionKind.SAGA, ids))
            }
        for (collection in custom.sortedBy { it.name.lowercase() }) {
            result.add(
                LibraryCollection(
                    customId(collection.id), collection.name, CollectionKind.CUSTOM,
                    customMembers[collection.id].orEmpty(),
                ),
            )
        }
        return result
    }

    /** Ordena [entries] según [sort]. El orden por título usa el título que se muestra. */
    fun sorted(entries: List<GameEntry>, metas: Map<String, GameMeta>, sort: LibrarySort): List<GameEntry> =
        when (sort) {
            LibrarySort.TITLE -> entries.sortedBy { it.displayTitle.lowercase() }
            LibrarySort.LAST_PLAYED -> entries.sortedWith(
                compareByDescending<GameEntry> { metas[it.id]?.lastPlayedAt ?: 0L }
                    .thenBy { it.displayTitle.lowercase() },
            )
            LibrarySort.ADDED -> entries.sortedWith(
                compareByDescending<GameEntry> { it.addedAt }.thenBy { it.displayTitle.lowercase() },
            )
        }

    /** «Continuar jugando»: los últimos juegos empezados que no se han marcado como terminados. */
    fun continuePlaying(entries: List<GameEntry>, metas: Map<String, GameMeta>, limit: Int = 10): List<GameEntry> =
        entries.filter { (metas[it.id]?.lastPlayedAt ?: 0L) > 0L && metas[it.id]?.completed != true }
            .sortedByDescending { metas[it.id]?.lastPlayedAt ?: 0L }
            .take(limit)

    /** Los juegos jugados más recientemente, sin importar si se marcaron como terminados. */
    fun recentlyPlayed(entries: List<GameEntry>, metas: Map<String, GameMeta>, limit: Int = RECENT_LIMIT): List<GameEntry> =
        entries.filter { (metas[it.id]?.lastPlayedAt ?: 0L) > 0L }
            .sortedByDescending { metas[it.id]?.lastPlayedAt ?: 0L }
            .take(limit)

    /** Texto buscable de un juego: el título mostrado, el nombre original y la saga. */
    fun searchText(entry: GameEntry, classification: GameClassification): String =
        listOfNotNull(entry.displayTitle, entry.title, classification.saga, classification.subseries)
            .joinToString(" ")
}

/**
 * El contrato entre la interfaz común y el anfitrión (Android): el estado de la organización y
 * lo que hace cada acción. Si el anfitrión no lo da, la biblioteca se comporta como antes.
 */
class LibraryOrganization(
    val metas: Map<String, GameMeta> = emptyMap(),
    val customCollections: List<CustomCollection> = emptyList(),
    val sort: LibrarySort = LibrarySort.TITLE,
    val folders: List<LibraryFolder> = emptyList(),
    /** Última fecha (ms) del autoguardado de cada juego que tiene uno. */
    val autoSaves: Map<String, Long> = emptyMap(),
    /** Un juego cuya última sesión no se cerró bien y tiene autoguardado. */
    val recoverableGameId: String? = null,
    val recoverableAt: Long = 0L,
    /** Se llama una vez abierto el lector del juego recuperable: carga su autoguardado. */
    val onRecover: () -> Unit = {},
    /** Copias rotativas de la partida normal de un juego. */
    val onListBackups: (String) -> List<SaveBackupInfo> = { emptyList() },
    val onRestoreBackup: (String, Int) -> Unit = { _, _ -> },
    /** Da formato a una fecha en milisegundos (lo aporta el anfitrión, con la configuración regional). */
    val formatTime: (Long) -> String = { it.toString() },
    val onSortChange: (LibrarySort) -> Unit = {},
    val onToggleFavorite: (String) -> Unit = {},
    /** Id del juego y título nuevo; null devuelve el título automático. */
    val onRename: (String, String?) -> Unit = { _, _ -> },
    /** Id del juego y saga elegida a mano. */
    val onSetSaga: (String, String) -> Unit = { _, _ -> },
    val onIgnoreSaga: (String) -> Unit = {},
    /** Quita todas las correcciones manuales de clasificación de un juego. */
    val onResetClassification: (String) -> Unit = {},
    val onToggleHack: (String) -> Unit = {},
    val onToggleCompleted: (String) -> Unit = {},
    val onCreateCollection: (String) -> Unit = {},
    val onDeleteCollection: (String) -> Unit = {},
    /** Id del juego e id de la colección: añade o quita. */
    val onToggleInCollection: (String, String) -> Unit = { _, _ -> },
    /** Quita el juego de la biblioteca (su copia privada); sus partidas y sus archivos originales no se tocan. */
    val onRemoveGame: (String) -> Unit = {},
    val onAddFolder: () -> Unit = {},
    val onRemoveFolder: (String) -> Unit = {},
    val onRescan: () -> Unit = {},
    val onDismissRecovery: () -> Unit = {},
)
