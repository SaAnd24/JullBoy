package com.ravenemu.android.library

import com.ravenemu.shared.library.CustomCollection
import com.ravenemu.shared.library.GameMeta
import com.ravenemu.shared.library.LibrarySort
import com.ravenemu.shared.settings.GameProfile
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LibraryOrganizationStoreTest {
    @get:Rule val temp = TemporaryFolder()
    private val key = "a".repeat(64)

    @Test fun `lo organizado se conserva entre aperturas`() {
        val folder = temp.newFolder()
        LibraryOrganizationStore(folder).update {
            it.copy(
                metas = mapOf(key to GameMeta(favorite = true, sagaOverride = "Mario", titleOverride = "Mi juego",
                    hackOverride = true, collections = setOf("c1"))),
                profiles = mapOf(key to GameProfile(fastForwardSpeed = 3, videoPalette = "dmg")),
                collections = listOf(CustomCollection("c1", "Viaje")),
                sort = LibrarySort.LAST_PLAYED,
            )
        }
        val read = LibraryOrganizationStore(folder).read()
        val meta = read.metas.getValue(key)
        assertTrue(meta.favorite)
        assertEquals("Mario", meta.sagaOverride)
        assertEquals("Mi juego", meta.titleOverride)
        assertEquals(true, meta.hackOverride)
        assertEquals(setOf("c1"), meta.collections)
        assertEquals(3, read.profiles.getValue(key).fastForwardSpeed)
        assertEquals("Viaje", read.collections.single().name)
        assertEquals(LibrarySort.LAST_PLAYED, read.sort)
    }

    @Test fun `un archivo dañado no impide abrir la biblioteca`() {
        val folder = temp.newFolder()
        File(folder, "organization.json").writeText("{ esto no es json")
        val read = LibraryOrganizationStore(folder).read()
        assertTrue(read.metas.isEmpty())
        assertNull(read.metas[key])
    }

    @Test fun `claves que no son una huella se ignoran`() {
        val folder = temp.newFolder()
        File(folder, "organization.json").writeText(
            """{"version":1,"games":{"../../etc":{"favorite":true},"$key":{"favorite":true}}}""",
        )
        assertEquals(setOf(key), LibraryOrganizationStore(folder).read().metas.keys)
    }
}
