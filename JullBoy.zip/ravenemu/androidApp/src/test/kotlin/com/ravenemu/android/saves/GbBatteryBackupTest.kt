package com.ravenemu.android.saves

import java.io.File
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GbBatteryBackupTest {
    @get:Rule val temp = TemporaryFolder()
    private val key = "b".repeat(64)

    @Test fun `conserva las tres ultimas copias y no repite una igual`() {
        val store = GbBatteryStore(temp.newFolder())
        for (version in 1..5) {
            store.write(key, byteArrayOf(version.toByte(), 9))
            store.backupRotating(key)
            store.backupRotating(key) // idéntica: no crea otra copia
        }
        assertEquals(listOf(1, 2, 3), store.backups(key).map { it.first })
        assertArrayEquals(byteArrayOf(5, 9), store.readBackup(key, 1))
        assertArrayEquals(byteArrayOf(4, 9), store.readBackup(key, 2))
        assertArrayEquals(byteArrayOf(3, 9), store.readBackup(key, 3))
        // El guardado real no se toca.
        assertArrayEquals(byteArrayOf(5, 9), store.read(key))
    }

    @Test fun `sin guardado no hay copias`() {
        val store = GbBatteryStore(temp.newFolder())
        store.backupRotating(key)
        assertEquals(emptyList<Int>(), store.backups(key).map { it.first })
        assertNull(store.readBackup(key, 1))
    }

    @Test fun `el estado de recuperacion es independiente de los emplacements`() {
        val states = GbSaveStateStore(temp.newFolder())
        states.write(key, byteArrayOf(1), 0)
        states.writeAuto(key, byteArrayOf(2))
        assertArrayEquals(byteArrayOf(1), states.read(key, 0))
        assertArrayEquals(byteArrayOf(2), states.readAuto(key))
        states.deleteAuto(key)
        assertNull(states.readAuto(key))
        assertArrayEquals(byteArrayOf(1), states.read(key, 0))
    }
}
