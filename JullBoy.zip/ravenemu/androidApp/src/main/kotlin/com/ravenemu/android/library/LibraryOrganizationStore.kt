package com.ravenemu.android.library

import android.util.AtomicFile
import com.ravenemu.shared.library.CustomCollection
import com.ravenemu.shared.library.GameMeta
import com.ravenemu.shared.library.LibraryFolder
import com.ravenemu.shared.library.LibrarySort
import com.ravenemu.shared.settings.GameProfile
import java.io.File
import java.io.FileNotFoundException
import org.json.JSONArray
import org.json.JSONObject

/**
 * JullBoy · datos de organización de la biblioteca: favoritos, correcciones manuales, colecciones
 * propias, perfiles por juego y carpetas autorizadas.
 *
 * Es un archivo aparte (`organization.json`) con escritura atómica. No toca los archivos ROM, el
 * índice de juegos ni las partidas: borrarlo solo devuelve la biblioteca a la clasificación
 * automática. Todo se asocia a la huella SHA-256 de la ROM.
 * Llamar desde un hilo de fondo.
 */
internal class LibraryOrganizationStore(directory: File) {
    private val file = AtomicFile(File(directory, "organization.json"))
    private val lock = Any()

    data class Data(
        val metas: Map<String, GameMeta> = emptyMap(),
        val profiles: Map<String, GameProfile> = emptyMap(),
        val collections: List<CustomCollection> = emptyList(),
        val folders: List<StoredFolder> = emptyList(),
        val sort: LibrarySort = LibrarySort.TITLE,
        /** Documento -> «tamaño:modificado» → huella, para no releer ROM sin cambios al reescanear. */
        val scanned: Map<String, ScannedFile> = emptyMap(),
    )

    data class StoredFolder(val uri: String, val label: String) {
        /** Identificador estable para la interfaz. */
        val id: String get() = uri
        fun toView() = LibraryFolder(id, label)
    }

    data class ScannedFile(val signature: String, val romKey: String)

    fun read(): Data = synchronized(lock) { readLocked() }

    fun update(change: (Data) -> Data): Data = synchronized(lock) {
        val updated = change(readLocked())
        writeLocked(updated)
        updated
    }

    private fun readLocked(): Data {
        val text = try {
            val bytes = file.openRead().use { it.readBytes() }
            if (bytes.size > MAX_BYTES) return Data()
            bytes.toString(Charsets.UTF_8)
        } catch (_: FileNotFoundException) {
            return Data()
        } catch (_: Exception) {
            return Data()
        }
        return try {
            parse(JSONObject(text))
        } catch (_: Exception) {
            // Un archivo dañado no debe impedir abrir la biblioteca: vuelve a la clasificación automática.
            Data()
        }
    }

    private fun parse(root: JSONObject): Data {
        val metas = HashMap<String, GameMeta>()
        root.optJSONObject("games")?.let { games ->
            for (key in games.keys()) {
                if (!validKey(key)) continue
                val item = games.optJSONObject(key) ?: continue
                val collections = HashSet<String>()
                item.optJSONArray("collections")?.let { array ->
                    for (i in 0 until array.length()) array.optString(i).takeIf { it.isNotEmpty() }?.let(collections::add)
                }
                metas[key] = GameMeta(
                    favorite = item.optBoolean("favorite", false),
                    lastPlayedAt = item.optLong("lastPlayedAt", 0L),
                    playCount = item.optInt("playCount", 0),
                    titleOverride = item.optString("title").takeIf { it.isNotBlank() },
                    sagaOverride = item.optString("saga").takeIf { it.isNotBlank() },
                    sagaIgnored = item.optBoolean("sagaIgnored", false),
                    hackOverride = if (item.has("hack")) item.optBoolean("hack") else null,
                    completed = item.optBoolean("completed", false),
                    collections = collections,
                )
            }
        }
        val profiles = HashMap<String, GameProfile>()
        root.optJSONObject("profiles")?.let { items ->
            for (key in items.keys()) {
                if (!validKey(key)) continue
                val item = items.optJSONObject(key) ?: continue
                val profile = GameProfile(
                    fastForwardSpeed = if (item.has("ff")) item.optInt("ff") else null,
                    videoPalette = item.optString("palette").takeIf { it.isNotBlank() },
                    integerScale = if (item.has("integer")) item.optBoolean("integer") else null,
                    controlsScale = if (item.has("controls")) item.optInt("controls") else null,
                )
                if (!profile.isEmpty) profiles[key] = profile
            }
        }
        val collections = ArrayList<CustomCollection>()
        root.optJSONArray("collections")?.let { array ->
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val name = item.optString("name")
                if (id.isNotEmpty() && name.isNotBlank()) collections.add(CustomCollection(id, name))
            }
        }
        val folders = ArrayList<StoredFolder>()
        root.optJSONArray("folders")?.let { array ->
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val uri = item.optString("uri")
                if (uri.isNotEmpty()) folders.add(StoredFolder(uri, item.optString("label").ifBlank { uri }))
            }
        }
        val scanned = HashMap<String, ScannedFile>()
        root.optJSONObject("scanned")?.let { items ->
            for (key in items.keys()) {
                val item = items.optJSONObject(key) ?: continue
                val romKey = item.optString("rom")
                if (validKey(romKey)) scanned[key] = ScannedFile(item.optString("sig"), romKey)
            }
        }
        val sort = runCatching { LibrarySort.valueOf(root.optString("sort", "TITLE")) }
            .getOrDefault(LibrarySort.TITLE)
        return Data(metas, profiles, collections, folders, sort, scanned)
    }

    private fun writeLocked(data: Data) {
        val games = JSONObject()
        for ((key, meta) in data.metas) {
            // Una ficha sin nada que recordar no ocupa sitio.
            if (meta == GameMeta()) continue
            val item = JSONObject()
                .put("favorite", meta.favorite)
                .put("lastPlayedAt", meta.lastPlayedAt)
                .put("playCount", meta.playCount)
                .put("sagaIgnored", meta.sagaIgnored)
                .put("completed", meta.completed)
            meta.titleOverride?.let { item.put("title", it) }
            meta.sagaOverride?.let { item.put("saga", it) }
            meta.hackOverride?.let { item.put("hack", it) }
            if (meta.collections.isNotEmpty()) item.put("collections", JSONArray(meta.collections.toList()))
            games.put(key, item)
        }
        val profiles = JSONObject()
        for ((key, profile) in data.profiles) {
            if (profile.isEmpty) continue
            val item = JSONObject()
            profile.fastForwardSpeed?.let { item.put("ff", it) }
            profile.videoPalette?.let { item.put("palette", it) }
            profile.integerScale?.let { item.put("integer", it) }
            profile.controlsScale?.let { item.put("controls", it) }
            profiles.put(key, item)
        }
        val collections = JSONArray()
        for (c in data.collections) collections.put(JSONObject().put("id", c.id).put("name", c.name))
        val folders = JSONArray()
        for (f in data.folders) folders.put(JSONObject().put("uri", f.uri).put("label", f.label))
        val scanned = JSONObject()
        for ((key, value) in data.scanned) {
            scanned.put(key, JSONObject().put("sig", value.signature).put("rom", value.romKey))
        }
        val bytes = JSONObject()
            .put("version", 1)
            .put("sort", data.sort.name)
            .put("games", games)
            .put("profiles", profiles)
            .put("collections", collections)
            .put("folders", folders)
            .put("scanned", scanned)
            .toString().toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_BYTES) { "Los datos de organización son demasiado grandes." }
        file.parentDirectoryCreated()
        val output = file.startWrite()
        try {
            output.write(bytes)
            file.finishWrite(output)
        } catch (error: Exception) {
            file.failWrite(output)
            throw error
        }
    }

    private fun AtomicFile.parentDirectoryCreated() {
        val parent = baseFile.parentFile
        check(parent == null || parent.isDirectory || parent.mkdirs()) {
            "Impossible de créer le dossier de la bibliothèque."
        }
    }

    private fun validKey(key: String): Boolean =
        key.length == 64 && key.all { it in '0'..'9' || it in 'a'..'f' }

    private companion object {
        const val MAX_BYTES = 1024 * 1024
    }
}
