package com.ravenemu.android.deltaskin

import com.ravenemu.shared.player.GbButton
import java.util.Locale
import kotlin.math.floor

data class DeltaSkinVisualTarget(
    val itemIndex: Int,
    /** 0..8 pour une cellule de D-pad, null pour l'item complet. */
    val dpadCell: Int? = null,
    val rect: DeltaSkinRect,
)

data class DeltaSkinMappedInput(
    val buttons: Set<GbButton> = emptySet(),
    val menu: Boolean = false,
    val visuals: Set<DeltaSkinVisualTarget> = emptySet(),
)

/**
 * Applique exactement la même transformation au dessin et aux hitboxes.
 * L'extension tactile est bornée au panneau et ne modifie jamais la frame
 * visuelle utilisée pour découper le D-pad.
 */
class DeltaSkinInputMapper(
    private val console: DeltaSkinConsole,
    private val representation: DeltaSkinRepresentation,
    private val panel: DeltaSkinRect,
) {
    fun inputAt(x: Double, y: Double): DeltaSkinMappedInput {
        if (!panel.contains(x, y)) return DeltaSkinMappedInput()
        val buttons = linkedSetOf<GbButton>()
        val visuals = linkedSetOf<DeltaSkinVisualTarget>()
        var menu = false

        val hitItems = representation.items.mapIndexedNotNull { index, item ->
            val visualFrame = DeltaSkinLayoutCalculator.mapFrame(
                item.frame,
                panel,
                representation.mappingSize,
            )
            val edges = item.extendedEdges.resolvedOver(representation.extendedEdges)
            val scaleX = panel.width / representation.mappingSize.width
            val scaleY = panel.height / representation.mappingSize.height
            val expanded = DeltaSkinRect(
                left = visualFrame.left - edges.left * scaleX,
                top = visualFrame.top - edges.top * scaleY,
                right = visualFrame.right + edges.right * scaleX,
                bottom = visualFrame.bottom + edges.bottom * scaleY,
            ).intersect(panel) ?: return@mapIndexedNotNull null
            if (!expanded.contains(x, y)) return@mapIndexedNotNull null
            HitItem(
                index = index,
                item = item,
                visualFrame = visualFrame,
                insideVisualFrame = visualFrame.contains(x, y),
            )
        }.let { hits ->
            // Une frame dessinée gagne sur l'extension d'une frame voisine.
            // Les extensions restent donc utiles dans les espaces vides sans
            // créer de combinaison accidentelle au-dessus d'un autre bouton.
            hits.filter(HitItem::insideVisualFrame).ifEmpty { hits }
        }

        hitItems.forEach { hit ->
            when (val inputs = hit.item.inputs) {
                is DeltaSkinInputs.Buttons -> {
                    val mapped = inputs.values.mapNotNull(::mapButton)
                    val itemHasMenu =
                        inputs.values.any { it.trim().equals("menu", true) }
                    buttons += mapped
                    menu = menu || itemHasMenu
                    if (mapped.isNotEmpty() || itemHasMenu) {
                        visuals += DeltaSkinVisualTarget(
                            hit.index,
                            rect = hit.visualFrame,
                        )
                    }
                }
                is DeltaSkinInputs.Directional -> {
                    val cell = dpadCell(x, y, hit.visualFrame)
                    val directions = directionsForCell(cell)
                    for (direction in directions) {
                        inputs.values[direction]?.let(::mapButton)?.let(buttons::add)
                    }
                    if (directions.any { inputs.values[it]?.trim()?.equals("menu", true) == true }) {
                        menu = true
                    }
                    if (directions.isNotEmpty()) {
                        visuals += DeltaSkinVisualTarget(
                            itemIndex = hit.index,
                            dpadCell = cell,
                            rect = dpadCellRect(hit.visualFrame, cell),
                        )
                    }
                }
            }
        }
        return DeltaSkinMappedInput(buttons = buttons, menu = menu, visuals = visuals)
    }

    private data class HitItem(
        val index: Int,
        val item: DeltaSkinItem,
        val visualFrame: DeltaSkinRect,
        val insideVisualFrame: Boolean,
    )

    private fun dpadCell(x: Double, y: Double, frame: DeltaSkinRect): Int {
        val clampedX = x.coerceIn(frame.left, frame.right)
        val clampedY = y.coerceIn(frame.top, frame.bottom)
        val column = floor(
            ((clampedX - frame.left) / frame.width * 3.0).coerceIn(0.0, 2.999_999)
        ).toInt()
        val row = floor(
            ((clampedY - frame.top) / frame.height * 3.0).coerceIn(0.0, 2.999_999)
        ).toInt()
        return row * 3 + column
    }

    private fun directionsForCell(cell: Int): Set<String> = when (cell) {
        0 -> setOf("up", "left")
        1 -> setOf("up")
        2 -> setOf("up", "right")
        3 -> setOf("left")
        4 -> emptySet()
        5 -> setOf("right")
        6 -> setOf("down", "left")
        7 -> setOf("down")
        8 -> setOf("down", "right")
        else -> emptySet()
    }

    private fun dpadCellRect(frame: DeltaSkinRect, cell: Int): DeltaSkinRect {
        val column = cell % 3
        val row = cell / 3
        val cellWidth = frame.width / 3.0
        val cellHeight = frame.height / 3.0
        return DeltaSkinRect(
            left = frame.left + column * cellWidth,
            top = frame.top + row * cellHeight,
            right = frame.left + (column + 1) * cellWidth,
            bottom = frame.top + (row + 1) * cellHeight,
        )
    }

    private fun mapButton(raw: String): GbButton? = when (raw.trim().lowercase(Locale.ROOT)) {
        "up" -> GbButton.UP
        "down" -> GbButton.DOWN
        "left" -> GbButton.LEFT
        "right" -> GbButton.RIGHT
        "a" -> GbButton.A
        "b" -> GbButton.B
        "start" -> GbButton.START
        "select" -> GbButton.SELECT
        "l" -> GbButton.L.takeIf { console == DeltaSkinConsole.GBA }
        "r" -> GbButton.R.takeIf { console == DeltaSkinConsole.GBA }
        else -> null
    }
}

data class DeltaSkinButtonChanges(
    val pressed: Set<GbButton>,
    val released: Set<GbButton>,
)

/**
 * Références de boutons par pointeur. Un bouton n'est relâché que lorsque le
 * dernier doigt qui le maintient quitte sa zone.
 */
class DeltaSkinInputState(
    private val onButtonsChanged: (DeltaSkinButtonChanges) -> Unit,
    private val onMenu: () -> Unit,
    private val onVisualsChanged: (Set<DeltaSkinVisualTarget>) -> Unit = {},
) {
    private val pointers = linkedMapOf<Int, DeltaSkinMappedInput>()
    private var buttonCounts = emptyMap<GbButton, Int>()
    private var menuCount = 0

    fun updatePointer(pointerId: Int, input: DeltaSkinMappedInput) {
        val previous = pointers[pointerId] ?: DeltaSkinMappedInput()
        if (previous == input) return
        if (input.buttons.isEmpty() && !input.menu && input.visuals.isEmpty()) {
            pointers.remove(pointerId)
        } else {
            pointers[pointerId] = input
        }
        publishState()
    }

    fun releasePointer(pointerId: Int) {
        if (pointers.remove(pointerId) != null) publishState()
    }

    fun releaseAll() {
        if (pointers.isEmpty() && buttonCounts.isEmpty() && menuCount == 0) return
        pointers.clear()
        publishState()
    }

    fun activeVisuals(): Set<DeltaSkinVisualTarget> =
        pointers.values.flatMapTo(linkedSetOf()) { it.visuals }

    private fun publishState() {
        val newCounts = mutableMapOf<GbButton, Int>()
        var newMenuCount = 0
        for (input in pointers.values) {
            input.buttons.forEach { button ->
                newCounts[button] = (newCounts[button] ?: 0) + 1
            }
            if (input.menu) newMenuCount++
        }
        val pressed = newCounts.keys.filterTo(linkedSetOf()) { (buttonCounts[it] ?: 0) == 0 }
        val released = buttonCounts.keys.filterTo(linkedSetOf()) { (newCounts[it] ?: 0) == 0 }
        buttonCounts = newCounts
        if (pressed.isNotEmpty() || released.isNotEmpty()) {
            onButtonsChanged(DeltaSkinButtonChanges(pressed = pressed, released = released))
        }
        if (menuCount == 0 && newMenuCount > 0) onMenu()
        menuCount = newMenuCount
        onVisualsChanged(activeVisuals())
    }
}
