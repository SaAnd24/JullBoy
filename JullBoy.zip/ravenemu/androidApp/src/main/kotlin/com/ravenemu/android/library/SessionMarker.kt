package com.ravenemu.android.library

import android.util.AtomicFile
import java.io.File
import java.io.FileNotFoundException
import org.json.JSONObject

/**
 * JullBoy · marca de la última sesión de juego. Se escribe al abrir un juego y se limpia al salir
 * del lector: si al arrancar la app sigue ahí, la sesión anterior no se cerró bien y se puede
 * ofrecer recuperar el estado autoguardado. Solo guarda el id del juego y la hora.
 */
internal class SessionMarker(directory: File) {
    private val file = AtomicFile(File(directory, "last-session.json"))

    data class Open(val romKey: String, val startedAt: Long)

    fun begin(romKey: String) {
        write(JSONObject().put("rom", romKey).put("at", System.currentTimeMillis()))
    }

    fun end() {
        file.delete()
    }

    /** La sesión que quedó abierta, o null si la última terminó con normalidad. */
    fun open(): Open? = try {
        val bytes = file.openRead().use { it.readBytes() }
        val json = JSONObject(bytes.toString(Charsets.UTF_8))
        val key = json.getString("rom")
        if (key.length == 64 && key.all { it in '0'..'9' || it in 'a'..'f' }) Open(key, json.optLong("at", 0L)) else null
    } catch (_: FileNotFoundException) {
        null
    } catch (_: Exception) {
        null
    }

    private fun write(json: JSONObject) {
        val parent = file.baseFile.parentFile
        if (parent != null && !parent.isDirectory) parent.mkdirs()
        val output = file.startWrite()
        try {
            output.write(json.toString().toByteArray(Charsets.UTF_8))
            file.finishWrite(output)
        } catch (error: Exception) {
            file.failWrite(output)
            throw error
        }
    }
}
