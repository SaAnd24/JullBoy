package com.ravenemu.android.library

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import com.ravenemu.shared.library.CustomCollection
import com.ravenemu.shared.library.GameEntry
import com.ravenemu.shared.library.GameMeta
import com.ravenemu.shared.library.GbFolderImportSummary
import com.ravenemu.shared.library.LibraryFolder
import com.ravenemu.shared.library.LibraryOrganization
import com.ravenemu.shared.library.LibrarySort
import com.ravenemu.shared.library.LoadedGameInfo
import com.ravenemu.shared.library.SaveBackupInfo
import com.ravenemu.shared.library.SmartCollections
import com.ravenemu.shared.settings.GameProfile
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.ravenemu.android.engine.AndroidGbSession
import com.ravenemu.android.link.AndroidLinkSession
import com.ravenemu.android.player.GbPlayerUi
import com.ravenemu.android.retro.AchievementsController

/**
 * The game library as the screens show it: the stored games, their import
 * and refresh, and the games loaded from it. One operation runs at a time
 * ([operations] is shared with the save transfers), never while the player
 * is open.
 */
internal class GbLibraryUi(
    private val applicationContext: Context,
    private val contentResolver: ContentResolver,
    private val romLibrary: GbRomLibrary,
    private val covers: GbCoversUi,
    private val gameSession: AndroidGbSession,
    private val linkSession: AndroidLinkSession,
    private val retro: AchievementsController,
    private val player: GbPlayerUi,
    private val operations: LibraryOperationGate,
    private val scope: CoroutineScope,
    // JullBoy: organización virtual, perfiles y marca de sesión. Archivos aparte de la biblioteca.
    private val organizationStore: LibraryOrganizationStore =
        LibraryOrganizationStore(File(applicationContext.filesDir, "gb-library")),
    private val sessionMarker: SessionMarker = SessionMarker(File(applicationContext.filesDir, "gb-library")),
) {
    /** Lo que el usuario organizó (favoritos, sagas corregidas, colecciones…). */
    var organizationData by mutableStateOf(LibraryOrganizationStore.Data())
        private set
    var recoverableGameId by mutableStateOf<String?>(null)
        private set
    var recoverableAt by mutableStateOf(0L)
        private set

    var games by mutableStateOf(emptyList<GameEntry>())
        private set
    var loadedGame by mutableStateOf<LoadedGameInfo?>(null)
        private set
    var activeGameId by mutableStateOf<String?>(null)
        private set
    // Each refresh from the library menu searches the missing covers again.
    private var refreshes by mutableStateOf(0)
    var loading by mutableStateOf(false)
        private set
    var importError by mutableStateOf<String?>(null)
        private set
    var folderImportProgress by mutableStateOf<String?>(null)
        private set
    var folderImportSummary by mutableStateOf<GbFolderImportSummary?>(null)
        private set

    @Composable
    fun Effects(onlineCovers: Boolean) {
        LaunchedEffect(this) {
            try {
                reload()
                detectRecoverableSession()
            } catch (error: Exception) {
                Log.e("RavenEmuLibrary", "Cannot open library index", error)
            }
        }
        // Only run a cover search when the user enabled it, and then only
        // when the library changes, an excluded ROM is explicitly
        // re-enabled or the library is refreshed. Recomposition/video
        // frames never initiate network calls.
        LaunchedEffect(games, covers.ignoredAutoCovers, onlineCovers, refreshes) {
            covers.fillMissingOnline(games, onlineCovers)
        }
    }

    private fun storedGames(): List<GameEntry> {
        val data = organizationStore.read()
        organizationData = data
        return romLibrary.list().map { stored ->
            val entry = GameEntry(stored.id, stored.filename, stored.platform, addedAt = stored.addedAt)
            entry.copy(displayTitle = SmartCollections.displayTitle(entry, data.metas[stored.id]))
        }
    }

    // Games and covers as stored; throws when the index cannot be read.
    private suspend fun reload() {
        val (stored, coverImages) = withContext(Dispatchers.IO) {
            val entries = storedGames()
            val pictures = entries.mapNotNull { entry ->
                try {
                    covers.coverStore.read(entry.id)?.asImageBitmap()?.let { entry.id to it }
                } catch (error: Exception) {
                    Log.w("RavenEmuLibrary", "Cannot read cover for ${entry.id.take(12)}", error)
                    null
                }
            }.toMap()
            entries to pictures
        }
        games = stored
        covers.libraryCovers = coverImages
    }

    /**
     * Runs [task] as the only library operation, while the player is closed:
     * [start] then [progress] show at once, the task reports its own errors.
     */
    private fun exclusive(progress: String? = null, start: () -> Unit = {}, task: suspend () -> Unit) {
        if (loading || player.open) return
        val operation = operations.tryAcquire() ?: return
        loading = true
        importError = null
        start()
        folderImportProgress = progress
        scope.launch {
            try {
                task()
            } finally {
                folderImportProgress = null
                loading = false
                operation.close()
            }
        }
    }

    // OpenDocumentTree: JullBoy conserva el permiso de lectura de la carpeta elegida (solo de esa
    // carpeta, nunca acceso global al almacenamiento) para poder volver a escanearla. Las ROM
    // aceptadas se copian al almacenamiento privado, como antes; los originales no se tocan.
    fun importFolder(uri: Uri?) {
        if (uri == null) return
        scanFolders(listOf(uri), register = true)
    }

    private fun scanFolders(uris: List<Uri>, register: Boolean) {
        exclusive("Analizando carpeta…", start = { folderImportSummary = null }) {
            try {
                if (register) registerFolders(uris)
                val known = organizationData.scanned
                val outcome = withContext(Dispatchers.IO) {
                    var added = 0
                    var duplicate = 0
                    var invalid = 0
                    var unreadable = 0
                    var otherFiles = 0
                    var folders = 0
                    var limited = false
                    val failures = ArrayList<String>()
                    val seen = HashMap<String, LibraryOrganizationStore.ScannedFile>()
                    for (uri in uris) {
                        val importer = GbFolderImporter(contentResolver, romLibrary, known)
                        try {
                            val result = importer.importTree(uri) { scanned ->
                                if (scanned == 1 || scanned % 5 == 0) {
                                    scope.launch {
                                        folderImportProgress = "Escaneando… $scanned ROM examinadas"
                                    }
                                }
                            }
                            added += result.added
                            duplicate += result.duplicate
                            invalid += result.invalid
                            unreadable += result.unreadable
                            otherFiles += result.otherFiles
                            folders += result.folders
                            limited = limited || result.limited
                            seen.putAll(importer.newScans)
                        } catch (error: Exception) {
                            Log.e("RavenEmuFolder", "Folder scan failed", error)
                            failures.add(uri.lastPathSegment ?: uri.toString())
                            seen.putAll(importer.newScans)
                        }
                    }
                    organizationStore.update { data -> data.copy(scanned = data.scanned + seen) }
                    val summary = GbFolderImportSummary(added, duplicate, invalid, unreadable, otherFiles, folders, limited)
                    Triple(summary, failures, storedGames())
                }
                games = outcome.third
                folderImportSummary = outcome.first
                if (outcome.second.isNotEmpty()) {
                    importError = "No se pudo leer: " + outcome.second.joinToString(", ") +
                        ". Si cambiaste permisos, vuelve a elegir la carpeta."
                }
            } catch (error: Exception) {
                Log.e("RavenEmuFolder", "Folder ROM import failed", error)
                importError = "Importación de la carpeta imposible: " +
                    (error.message ?: "error desconocido")
                // Incluso una importación parcial ya confirmó sus ROM válidas.
                games = withContext(Dispatchers.IO) { storedGames() }
            }
        }
    }

    private suspend fun registerFolders(uris: List<Uri>) {
        for (uri in uris) {
            // El permiso persistente puede no concederse (algunos proveedores): el escaneo único funciona igual.
            runCatching {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        withContext(Dispatchers.IO) {
            organizationStore.update { data ->
                var folders = data.folders
                for (uri in uris) {
                    val key = uri.toString()
                    if (folders.none { it.uri == key }) {
                        val label = (uri.lastPathSegment ?: key).substringAfterLast(':').ifBlank { key }
                        folders = folders + LibraryOrganizationStore.StoredFolder(key, label)
                    }
                }
                data.copy(folders = folders)
            }
        }
        organizationData = withContext(Dispatchers.IO) { organizationStore.read() }
    }

    // ---------------------------------------------------------------- JullBoy: organización

    /** Aplica un cambio a los datos de organización, fuera del hilo principal, y refresca los títulos. */
    private fun changeOrganization(change: (LibraryOrganizationStore.Data) -> LibraryOrganizationStore.Data) {
        scope.launch {
            try {
                val data = withContext(Dispatchers.IO) { organizationStore.update(change) }
                organizationData = data
                games = games.map { entry ->
                    entry.copy(displayTitle = SmartCollections.displayTitle(entry, data.metas[entry.id]))
                }
            } catch (error: Exception) {
                Log.e("RavenEmuLibrary", "Cannot save library organization", error)
                Toast.makeText(applicationContext,
                    "No se pudo guardar el cambio: ${error.message ?: "error desconocido"}",
                    Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun changeMeta(id: String, change: (GameMeta) -> GameMeta) = changeOrganization { data ->
        val updated = change(data.metas[id] ?: GameMeta())
        data.copy(metas = if (updated == GameMeta()) data.metas - id else data.metas + (id to updated))
    }

    fun toggleFavorite(id: String) = changeMeta(id) { it.copy(favorite = !it.favorite) }

    fun rename(id: String, title: String?) = changeMeta(id) {
        it.copy(titleOverride = title?.trim()?.take(120)?.takeIf { text -> text.isNotEmpty() })
    }

    fun setSaga(id: String, saga: String) = changeMeta(id) {
        it.copy(sagaOverride = saga.trim().take(80).takeIf { text -> text.isNotEmpty() }, sagaIgnored = false)
    }

    fun ignoreSaga(id: String) = changeMeta(id) { it.copy(sagaOverride = null, sagaIgnored = true) }

    /** Quita las correcciones de clasificación; favoritos, colecciones e historial se conservan. */
    fun resetClassification(id: String) = changeMeta(id) {
        it.copy(titleOverride = null, sagaOverride = null, sagaIgnored = false, hackOverride = null)
    }

    fun toggleHack(id: String) {
        val entry = games.firstOrNull { it.id == id } ?: return
        changeMeta(id) { meta ->
            val current = meta.hackOverride ?: SmartCollections.classify(entry, meta).modified
            meta.copy(hackOverride = !current)
        }
    }

    fun toggleCompleted(id: String) = changeMeta(id) { it.copy(completed = !it.completed) }

    fun createCollection(name: String) {
        val clean = name.trim().take(40)
        if (clean.isEmpty()) return
        changeOrganization { data ->
            if (data.collections.any { it.name.equals(clean, ignoreCase = true) }) data
            else data.copy(collections = data.collections + CustomCollection("c" + System.currentTimeMillis(), clean))
        }
    }

    fun deleteCollection(id: String) = changeOrganization { data ->
        data.copy(
            collections = data.collections.filterNot { it.id == id },
            metas = data.metas.mapValues { (_, meta) -> meta.copy(collections = meta.collections - id) },
        )
    }

    fun toggleInCollection(gameId: String, collectionId: String) = changeMeta(gameId) { meta ->
        meta.copy(
            collections = if (collectionId in meta.collections) meta.collections - collectionId
            else meta.collections + collectionId,
        )
    }

    fun setSort(sort: LibrarySort) = changeOrganization { it.copy(sort = sort) }

    fun setProfile(id: String, profile: GameProfile) = changeOrganization { data ->
        data.copy(profiles = if (profile.isEmpty) data.profiles - id else data.profiles + (id to profile))
    }

    /** Anota que [id] acaba de abrirse: alimenta «Continuar jugando» y «Jugados recientemente». */
    private fun recordPlayed(id: String) = changeMeta(id) {
        it.copy(lastPlayedAt = System.currentTimeMillis(), playCount = it.playCount + 1)
    }

    /**
     * Retira [id] de la biblioteca. Solo se borra la copia privada de la ROM: sus partidas y los
     * archivos originales del usuario quedan intactos, y volver a importarla recupera su progreso.
     */
    fun removeGame(id: String) = exclusive("Retirando el juego…") {
        try {
            withContext(Dispatchers.IO) {
                gameSession.releaseForSaveImport(id)
                romLibrary.remove(id)
            }
            forgetLoaded(id)
            reload()
            Toast.makeText(applicationContext,
                "Juego retirado de la biblioteca. Sus partidas se han conservado.",
                Toast.LENGTH_LONG).show()
        } catch (error: Exception) {
            Log.e("RavenEmuLibrary", "Cannot remove game", error)
            importError = "No se pudo retirar el juego: " + (error.message ?: "error desconocido")
        }
    }

    // ---------------------------------------------------------------- JullBoy: carpetas

    val folders: List<LibraryFolder> get() = organizationData.folders.map { it.toView() }

    /** Vuelve a escanear todas las carpetas autorizadas; solo se leen los archivos nuevos o cambiados. */
    fun rescanFolders() {
        val uris = organizationData.folders.mapNotNull { runCatching { Uri.parse(it.uri) }.getOrNull() }
        if (uris.isEmpty()) {
            importError = "Aún no hay carpetas guardadas. Añade una con «Importar un dossier»."
            return
        }
        scanFolders(uris, register = false)
    }

    fun removeFolder(id: String) {
        runCatching {
            contentResolver.releasePersistableUriPermission(Uri.parse(id), android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        changeOrganization { data ->
            data.copy(
                folders = data.folders.filterNot { it.uri == id },
                scanned = data.scanned.filterKeys { !it.startsWith("$id|") },
            )
        }
    }

    // ---------------------------------------------------------------- JullBoy: recuperación

    private suspend fun detectRecoverableSession() {
        val (id, at) = withContext<Pair<String?, Long>>(Dispatchers.IO) {
            val open = sessionMarker.open() ?: return@withContext Pair(null, 0L)
            val saved = gameSession.autoStateTime(open.romKey)
            // Solo un autoguardado hecho durante esa sesión: uno anterior sería engañoso.
            if (saved != null && saved >= open.startedAt && games.any { it.id == open.romKey }) Pair(open.romKey, saved)
            else Pair(null, 0L)
        }
        recoverableGameId = id
        recoverableAt = at
    }

    fun dismissRecovery() {
        recoverableGameId = null
        scope.launch(Dispatchers.IO) { runCatching { sessionMarker.end() } }
    }

    /** Termina la sesión de juego: guarda el estado de recuperación si procede y limpia la marca. */
    fun finishSession(autosave: Boolean) {
        scope.launch(Dispatchers.IO) {
            try {
                if (autosave) gameSession.saveAutoState(AUTOSAVE_WAIT_MILLIS)
            } catch (error: Exception) {
                Log.e("RavenEmuSaves", "Auto state on exit failed", error)
            } finally {
                runCatching { sessionMarker.end() }
            }
        }
    }

    fun backupsOf(id: String): List<SaveBackupInfo> =
        gameSession.batteryBackups(id).map { (index, at, bytes) -> SaveBackupInfo(index, at, bytes) }

    /** Restaura una copia del guardado normal (el guardado actual pasa a ser otra copia). */
    fun restoreBackup(id: String, index: Int) = exclusive("Restaurando la copia…") {
        try {
            withContext(Dispatchers.IO) { gameSession.restoreBatteryBackup(id, index) }
            forgetLoaded(id)
            Toast.makeText(applicationContext,
                "Copia restaurada. La partida anterior se guardó como otra copia.",
                Toast.LENGTH_LONG).show()
        } catch (error: Exception) {
            Log.e("RavenEmuSaves", "Cannot restore battery backup", error)
            importError = "No se pudo restaurar la copia: " + (error.message ?: "error desconocido")
        }
    }

    /** Todo lo que la interfaz común necesita para organizar la biblioteca. */
    fun organization(
        formatTime: (Long) -> String = { it.toString() },
        onRecover: () -> Unit = {},
    ): LibraryOrganization {
        val data = organizationData
        return LibraryOrganization(
            metas = data.metas,
            customCollections = data.collections,
            sort = data.sort,
            folders = data.folders.map { it.toView() },
            recoverableGameId = recoverableGameId,
            recoverableAt = recoverableAt,
            formatTime = formatTime,
            onRecover = onRecover,
            onSortChange = ::setSort,
            onToggleFavorite = ::toggleFavorite,
            onRename = ::rename,
            onSetSaga = ::setSaga,
            onIgnoreSaga = ::ignoreSaga,
            onResetClassification = ::resetClassification,
            onToggleHack = ::toggleHack,
            onToggleCompleted = ::toggleCompleted,
            onCreateCollection = ::createCollection,
            onDeleteCollection = ::deleteCollection,
            onToggleInCollection = ::toggleInCollection,
            onRemoveGame = ::removeGame,
            onRemoveFolder = ::removeFolder,
            onRescan = ::rescanFolders,
            onDismissRecovery = ::dismissRecovery,
            onListBackups = ::backupsOf,
            onRestoreBackup = ::restoreBackup,
        )
    }

    fun dismissFolderImportSummary() {
        folderImportSummary = null
    }

    /** Imports one ROM and loads it, ready to play. */
    fun importRom(uri: Uri?) {
        if (uri == null) return
        exclusive {
            try {
                val (info, stored, rom) = withContext(Dispatchers.IO) {
                    // A pair just left behind writes its saves first.
                    linkSession.unload()
                    val (name, bytes) = romLibrary.readSelected(uri)
                    // Validate with native RavenGB before indexing the cartridge.
                    val info = gameSession.loadBytes(name, bytes)
                    val stored = romLibrary.add(name, bytes)
                    Triple(info, stored, bytes)
                }
                loadedGame = info
                activeGameId = stored.id
                try { retro.selectRom(rom, info.platform) }
                catch (error: Exception) {
                    Log.w("RavenEmuRetro", "RA identify failed after import", error)
                }
                games = withContext(Dispatchers.IO) { storedGames() }
            } catch (exception: Exception) {
                importError = exception.message ?: "Échec du chargement de la ROM."
            }
        }
    }

    fun refresh() = exclusive(progress = "Actualisation de la bibliothèque…") {
        try {
            reload()
            // Games the cover index did not know are searched again.
            covers.forgetUnmatched()
            refreshes++
            val count = games.size
            Toast.makeText(applicationContext,
                "Bibliothèque actualisée : $count ${if (count > 1) "jeux" else "jeu"}",
                Toast.LENGTH_SHORT).show()
        } catch (error: Exception) {
            Log.e("RavenEmuLibrary", "Library refresh failed", error)
            importError = "Actualisation impossible : " +
                (error.message ?: "erreur inconnue")
        }
    }

    // Settings > Console changed: the next launch loads its game afresh.
    private var reloadNext = false

    /** The console options take effect at the next launch, even of the game already loaded. */
    fun reloadOnNextLaunch() {
        reloadNext = true
    }

    /** Loads the stored game [id] unless it already is, then [onReady]. */
    fun launch(id: String, onReady: () -> Unit) = exclusive {
        try {
            if (activeGameId != id || loadedGame == null || reloadNext) {
                reloadNext = false
                val entry = games.firstOrNull { it.id == id }
                    ?: error("Ce jeu n'est plus dans la bibliothèque.")
                val (result, rom) = withContext(Dispatchers.IO) {
                    // A pair just left behind writes its saves first.
                    linkSession.unload()
                    val rom = romLibrary.readRom(id)
                    gameSession.loadBytes(entry.title, rom) to rom
                }
                loadedGame = result
                activeGameId = id
                try { retro.selectRom(rom, result.platform) }
                catch (error: Exception) {
                    Log.w("RavenEmuRetro", "RA identify failed on launch", error)
                }
            }
            recordPlayed(id)
            withContext(Dispatchers.IO) { runCatching { sessionMarker.begin(id) } }
            if (recoverableGameId == id) recoverableGameId = null
            onReady()
        } catch (error: Exception) {
            Log.e("RavenEmuLibrary", "Cannot load stored GB ROM", error)
            importError = error.message ?: "Impossible de lancer ce jeu."
        }
    }

    /** Loads two stored games joined by the link cable, then [onReady]. */
    fun launchLinked(firstId: String, secondId: String, onReady: () -> Unit) = exclusive {
        try {
            val ids = listOf(firstId, secondId)
            val entries = ids.map { id ->
                games.firstOrNull { it.id == id }
                    ?: error("Ce jeu n'est plus dans la bibliothèque.")
            }
            val infos = withContext(Dispatchers.IO) {
                val roms = entries.map { it.title to romLibrary.readRom(it.id) }
                // A game held by the single player writes its save and
                // leaves memory: only one copy of a save may run at once.
                for (id in ids) gameSession.releaseForSaveImport(id)
                linkSession.load(roms)
            }
            if (activeGameId in ids) {
                activeGameId = null
                loadedGame = null
            }
            player.showLinked(infos)
            onReady()
        } catch (error: Exception) {
            Log.e("RavenEmuLink", "Cannot load linked games", error)
            importError = error.message ?: "Impossible de relier ces jeux."
        }
    }

    private companion object {
        // Margen para el estado de recuperación al salir: nunca bloquea la salida más que esto.
        const val AUTOSAVE_WAIT_MILLIS = 1500L
    }

    /** The save of [romKey] was replaced: its game is loaded again at launch. */
    fun forgetLoaded(romKey: String) {
        if (activeGameId == romKey) {
            activeGameId = null
            loadedGame = null
        }
    }
}
