package com.ravenemu.android.saves

import android.util.AtomicFile
import java.io.File
import java.io.FileNotFoundException
import java.security.MessageDigest

/**
 * Battery-backed cartridge data (the game's own SAVE command), not a save state.
 * Private app storage, keyed by ROM content rather than its display filename.
 */
internal class GbBatteryStore(private val directory: File) {
    fun read(romKey: String): ByteArray? {
        val atomic = AtomicFile(fileFor(romKey))
        return try {
            atomic.openRead().use { stream ->
                val content = stream.readBytes()
                require(content.size <= MAX_BATTERY_BYTES) {
                    "La sauvegarde dépasse la taille maximale autorisée."
                }
                content
            }
        } catch (_: FileNotFoundException) {
            null
        }
    }

    fun write(romKey: String, bytes: ByteArray) {
        require(bytes.isNotEmpty() && bytes.size <= MAX_BATTERY_BYTES) {
            "Taille de sauvegarde batterie invalide."
        }
        check(directory.isDirectory || directory.mkdirs()) {
            "Impossible de créer le dossier des sauvegardes."
        }
        val atomic = AtomicFile(fileFor(romKey))
        val stream = atomic.startWrite()
        try {
            stream.write(bytes)
            atomic.finishWrite(stream)
        } catch (error: Exception) {
            atomic.failWrite(stream)
            throw error
        }
    }

    /** Only used to roll back an interrupted import of a previously absent save. */
    fun delete(romKey: String) {
        AtomicFile(fileFor(romKey)).delete()
    }

    /**
     * JullBoy · copias rotativas del guardado normal (.sav/.srm): antes de cada partida se guarda
     * una copia del estado actual si cambió desde la última, y se conservan las tres últimas
     * (`backups/<hash>.1.sav` es la más reciente). Nunca se borra ni se sobrescribe el guardado real.
     */
    fun backupRotating(key: String) {
        val current = try {
            AtomicFile(fileFor(key)).openRead().use { it.readBytes() }
        } catch (_: FileNotFoundException) {
            return
        }
        if (current.isEmpty() || current.size > MAX_BATTERY_BYTES) return
        val folder = File(directory, BACKUP_FOLDER)
        if (!folder.isDirectory && !folder.mkdirs()) return
        val first = backupFile(key, 1)
        if (first.isFile && first.readBytes().contentEquals(current)) return
        backupFile(key, BACKUP_COUNT).delete()
        for (index in BACKUP_COUNT - 1 downTo 1) {
            val from = backupFile(key, index)
            if (from.isFile) from.renameTo(backupFile(key, index + 1))
        }
        first.writeBytes(current)
    }

    /** Las copias existentes, de la más reciente a la más antigua: (número, fecha en ms, tamaño). */
    fun backups(key: String): List<Triple<Int, Long, Int>> =
        (1..BACKUP_COUNT).mapNotNull { index ->
            val file = backupFile(key, index)
            if (file.isFile) Triple(index, file.lastModified(), file.length().toInt()) else null
        }

    fun readBackup(key: String, index: Int): ByteArray? {
        require(index in 1..BACKUP_COUNT) { "Copia inexistante." }
        val file = backupFile(key, index)
        return if (file.isFile && file.length() in 1..MAX_BATTERY_BYTES.toLong()) file.readBytes() else null
    }

    private fun backupFile(key: String, index: Int): File {
        fileFor(key) // valida la clave
        return File(File(directory, BACKUP_FOLDER), "$key.$index.sav")
    }

    private fun fileFor(key: String): File {
        require(key.length == 64 && key.all { it in '0'..'9' || it in 'a'..'f' }) {
            "Identifiant de ROM invalide."
        }
        return File(directory, "$key.sav")
    }

    companion object {
        private const val MAX_BATTERY_BYTES = 2 * 1024 * 1024
        private const val BACKUP_FOLDER = "backups"
        const val BACKUP_COUNT = 3

        /** SHA-256 of the ROM bytes: renamed ROMs share their save, different games do not. */
        fun keyForRom(rom: ByteArray): String =
            MessageDigest.getInstance("SHA-256").digest(rom)
                .joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }
}
